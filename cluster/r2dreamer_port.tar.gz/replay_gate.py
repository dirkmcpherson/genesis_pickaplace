#!/usr/bin/env python
"""REPLAY GATE (non-negotiable, GENESIS_PORT_STATUS.md): open-loop replay of the
EXACT training rows (demo_prefill._load_episode, downsample = action_repeat)
through the GenesisPick adapter. A demo set + (action_mode, cap, leash) combo is
launchable only if the gated uids re-earn their pick terminal this way -- it
exercises the converter encoding, dreamer row convention, mean-pool downsample,
target integration, and the leash together.

Usage:
  ./.venv/bin/python replay_gate.py --demo-dir .../genesis_pick_pruned_delta25 \
      --delta-cap 0.025 --leash-mult 5 [--uids 232 242 243] [--slack 20]

History: 0.04-cap set PASSED 3/3 (uid 232 @60/71 agent steps, 242 @60/71,
243 @44/56); measured-q encoding FAILED here (PD-lag chasing) -- this gate is
what caught it.
"""
import argparse, glob, pathlib as pl, sys
import numpy as np

sys.path.insert(0, str(pl.Path(__file__).resolve().parent))
from demo_prefill import _load_episode  # noqa: E402
from envs.genesis import GenesisPick    # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument('--demo-dir', required=True)
ap.add_argument('--delta-cap', type=float, required=True)
ap.add_argument('--leash-mult', type=float, default=None)
ap.add_argument('--repeat', type=int, default=4)
ap.add_argument('--uids', nargs='+', default=['232', '242', '243'],
                help="uids to gate, or 'auto' = first 3 npz in the demo dir "
                     "(harvest sets have model-episode uids, not human trial ids)")
ap.add_argument('--raw-dir', default=None,
                help='RAW harvest npz dir (states array present). When set, '
                     'each uid resets via reset_to(can_pos=states[0][8:11]) '
                     'instead of trial_placements lookup -- REQUIRED for '
                     'harvested (model-demo) sets whose ICs are random support '
                     'draws, not recorded trials. Arm start is HARDCODED_START '
                     'in both paths (the collector resets the same way); goal '
                     'is the static goal captured from the initial reset.')
ap.add_argument('--slack', type=int, default=20,
                help='extra agent steps past tape end holding the final action '
                     '(open-loop replay lags the demo a few steps)')
args = ap.parse_args()
if args.uids == ['auto']:
    import re as _re
    _npz = sorted(pl.Path(args.demo_dir).glob('genesis-*.npz'))[:3]
    args.uids = [int(_re.match(r'genesis-(\d+)-', p.name).group(1)) for p in _npz]
    print(f'auto uids: {args.uids}')
else:
    args.uids = [int(u) for u in args.uids]

env = GenesisPick('pick', size=(64, 64), seed=0, scope='pick',
                  action_mode='delta_joint', action_repeat=args.repeat,
                  reward_scale=100.0, delta_cap=args.delta_cap,
                  delta_leash_mult=args.leash_mult)
env.reset()
import numpy as np  # noqa: E402
GOAL_POS = np.asarray(env._env.genv.w['goal'].get_pos(), dtype=float)  # static goal

n_pass = 0
for uid in args.uids:
    match = glob.glob(f'{args.demo_dir}/genesis-{uid:04d}-*.npz')
    assert len(match) == 1, (uid, match)
    ep = _load_episode(match[0], downsample=args.repeat, reward_scale=100.0)
    # _load_episode rows are FORWARD convention (action chosen AT obs_t; zero
    # placeholder on the final row) -- replay rows 0..T-2 in order.
    acts = ep['action'][:-1]
    if args.raw_dir:
        raw = glob.glob(f'{args.raw_dir}/{uid}_*.npz') or \
              glob.glob(f'{args.raw_dir}/*{uid}*.npz')
        assert raw, f'no raw npz for uid {uid} in {args.raw_dir}'
        cp = np.load(raw[0])['states'][0][8:11].astype(float)
        env._env.reset_to({'can_pos': list(cp), 'goal_pos': list(GOAL_POS)})
    else:
        env._env.reset(options={'uid': uid})
    env.sync_delta_target()
    total, done, t = 0.0, False, 0
    for a in acts:
        _, r, done, info = env.step(a)
        total += float(r); t += 1
        if done:
            break
    hold = 0
    while not done and hold < args.slack:          # PD catch-up past tape end
        _, r, done, info = env.step(acts[-1])
        total += float(r); t += 1; hold += 1
    ok = 'picked' in env._env._granted
    n_pass += ok
    print(f'uid {uid}: {"PASS" if ok else "FAIL"} reward {total:.0f} '
          f'@{t}/{len(acts)} agent steps (hold {hold})', flush=True)

print(f'\nGATE: {n_pass}/{len(args.uids)} passed')
sys.exit(0 if n_pass == len(args.uids) else 1)
