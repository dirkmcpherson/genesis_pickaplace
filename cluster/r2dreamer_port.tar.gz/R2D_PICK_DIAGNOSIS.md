# Why world-model learners fail genesis pick while DP (0.8) and SACfD (0.4-0.5) don't

2026-08-08. Evidence = `runs/genesis_pick_demo_s0/metrics.jsonl` (4088 episodes /
601 update snapshots over 3.1M steps), `runs/pick_dH_long_s0` (early), the two
policy_eval_20260808 evals, and their working configs (`configs/env/metaworld.yaml`,
`dmc_vision.yaml`) vs `genesis_pick.yaml`. All numbers below were read from those
files, not recalled.

## Ranked diagnosis

### 1. Entropy ratchet: the actor's only persistent gradient was the entropy bonus, and the final checkpoint is near-random. The "train ~20% vs eval 0-1/15" gap is CHECKPOINT TIMING, not an eval bug.

Policy loss is `-(logpi * adv + act_entropy * entropy)` (dreamer.py:502) with
`act_entropy = 3e-4` — dv3's dense-reward setting. On genesis_pick_demo_s0:

| step | action_entropy (nats) | adv mean | adv_std | action_std |
|---|---|---|---|---|
| 95k | **-0.45** | 0.018 | 0.097 | 0.75 |
| 1.2M | 3.04 | -0.001 | 0.061 | 0.94 |
| 2.3M | 7.66 | 0.002 | 0.036 | 1.21 |
| 3.1M | **9.18** | -0.000 | **0.008** | 1.29 |

Advantage is ~zero the whole run (sparse-reward value landscape is flat — see #2),
so 3e-4·entropy dominates and entropy climbs **monotonically for 3M steps** toward
the bounded_normal max. Train pick-rate windows: 2% → 13% (992k) → 18% (1.3M) →
**25% (2.57-2.78M)** → 11% → 0 (final window). The run had NO periodic checkpoint
(save_every landed later); `latest.pt` = the degraded END policy, which evals at
picked 1/15 sampling — consistent with its own final training windows. The mid-run
20-25% policy was never saved. Eval harness itself is proven bit-exact
(test_action_conditioning.py P1-P4; two independent evals gave identical
per-episode outcomes). On dmc/metaworld the same 3e-4 is harmless because dense
reward keeps |adv| orders of magnitude above the entropy term.

### 2. Critic poisoned by twohot reward-head leak × horizon 1000: value ~11 where the true max return is ≤ 1.

`horizon: 1000` (genesis_pick.yaml, vs the house default **333** used by every
working config) sets disc = 0.999; the cont head predicts ~1.0 (train/con
0.999-1.000). The symexp_twohot reward head hallucinates a small positive reward
on ~every imagined state (train/rew 0.003-0.006 early), and 0.005 × ~1000
effective horizon = **value 5-12 of pure leak**: value_replay_mean starts at
11.26, ret_005/ret_095 at 10.2/13.9 — on a task whose maximum possible return is
+1. The real pick terminal is a rounding error inside the advantage, and the
return-EMA normalization scale (ret_095-ret_005) is set by leak, further crushing
the true signal. As the reward head fit the zeros (loss/rew → 1e-4), val decayed
11.6 → 1.1 over 3M steps — the critic spent the whole run unlearning its own
hallucination instead of ranking states by pick progress. Working benchmarks are
insulated twice: horizon 333 (3× less amplification) and dense reward (leak is
negligible relative to signal).

### 3. Reward-signal starvation: <1 rewarded frame per 1024-frame batch, then demo eviction to ~zero.

Demo density is 79 rewarded terminals / 94,454 frames = 0.084%; at batch 16×64
that is ~0.86 rewarded frames/update at BEST. Measured train/data/reward_frames:
0.43 (early) → 0.04-0.2 after FIFO evicted all 95k demo frames by 700k of 3M
online steps (buffer 7e5, no reinjection in that run). dv3-torch's genesis config
already learned this lesson explicitly (its 32×96 batch comment: 16×64 gave ~1.1
rewarded frames, they needed ~3.4). `pick_dH_long_s0` fixes eviction
(reinject_every 300k + buffer 350k → demos stay ~27% of buffer; its early
metrics show a SANE value scale 0.01-0.23 and ret_replay_max 1.0) but inherits
act_entropy 3e-4 (entropy already 9.5-9.9 in its first snapshots — watch #1).

### 4. Timescale mismatch vs every working benchmark: 1200 agent steps/episode, reward at ~559.

genesis_pick: action_repeat 1, 1200 agent steps, demo-median pick at agent step
~559. metaworld: repeat 2, **250** agent steps. dmc: repeat 2, 500.
imag_horizon 15 covers 1.25% of a genesis episode (6% metaworld);
0.999^559 = 0.57 visibility at best, and lowering the discount at repeat 1 kills
visibility entirely (0.99^559 = 0.004) — which is why horizon got pushed to 1000
and #2 happened. This is the memory-file lesson ("gamma^(steps-to-reward) must be
visible; velocity caps stretch time-to-reward — cost 5 flat runs") in new
clothing. The demos are 30 Hz teleop tapes with smooth commands, so repeat 4 is
well-posed: window-mean demo action ≈ the held action.

### 5. Lesser findings
- No in-loop eval (`eval_episode_num 0`, genesis one-world constraint) + no
  periodic checkpoint in the s0 run = flew blind past the 2.6M peak. save_every
  1e5 now exists (dH run has it) — post-hoc eval of intermediate checkpoints is
  the cheap way to confirm #1 (predict: mid-run ckpts eval ≫ final).
- dyn_entropy drifts up 38.6 → 45.8 as the buffer fills with max-entropy policy
  data — world model quality degrades with the policy.
- DP/SACfD are structurally immune to all of the above: DP never uses
  reward/value (pure BC on the same demos), SACfD gets 1-step TD off real
  transitions + demo replay, no imagination leak, no horizon-1000 twohot head.

## Interventions implemented (genesis_pick_v2)

`configs/env/genesis_pick_v2.yaml` — two ranked interventions:

1. **action_repeat 4 + demo_downsample 4 + horizon 333** (attacks #2, #3, #4):
   pick at ~140 agent steps (0.997^140 = 0.66 visible), episodes 300 agent steps
   (metaworld-scale), leak amplification cut 3×, demo reward density ×4
   (79/23,719 rows = 0.33% ≈ 3.4 rewarded frames per 1024-frame batch — exactly
   the density dv3-torch measured it needed).
   Code: `envs/genesis.py` GenesisPick(action_repeat=) — N sim steps per agent
   step, rewards summed, early break on termination (default 1 = old behavior);
   `envs/__init__.py` passes config.action_repeat; `demo_prefill.py`
   `_load_episode(downsample=)` — stride 4 keeping the terminal frame,
   window-SUM reward (terminal +1 exact), window-MEAN backward-convention
   action, applied before the forward-shift; `add_demo_set` asserts
   demo_downsample == action_repeat (contradictory-dynamics guard);
   `eval_genesis.py` reads action_repeat from the run config (max-steps stays in
   sim steps).
2. **act_entropy 3e-5** (attacks #1): 10× down, below the observed adv scale.
   Hook: `model/_base_.yaml` `act_entropy: ${oc.select:env.act_entropy,3e-4}`
   (same cross-package pattern as horizon/actor_bc_lambda; all existing configs
   resolve to 3e-4 unchanged).

Also baked in (proven, not new): demo_reinject_every 300000, train_ratio 128.
The running `pick_dH_long_s0` was not touched (new adapter/prefill params all
default to old behavior; its process loaded its code at launch).

## Validation actually run (2026-08-08, CPU, separate processes)

`scratchpad/validate_v2.py` + a live-world probe — ALL PASS:
1. Hydra resolution: v2 → act_entropy 3e-5 / horizon 333 / trainer.action_repeat
   4; genesis_pick (v1) still resolves 3e-4 / 1000 / 1 (no behavior change for
   existing runs).
2. Full 91-npz downsample audit: 94,454 → 23,719 rows (×3.98), **79/79 rewarded
   terminals preserved**, reward mass exact per episode, is_first/is_last/
   is_terminal structure intact, final-row zero action (shift convention),
   actions in [-1,1]; window-mean action spot-checked elementwise vs raw npz.
3. Mismatch guard: demo_downsample 4 + action_repeat 1 raises with the
   contradictory-dynamics message.
4. Live CPU Genesis world: GenesisPick(action_repeat=4) + TimeLimit(1200//4):
   10 agent steps → FullTaskEnv._t == 40 sim steps exactly; TimeLimit duration
   300.

Suggested launch (after pick_dH_long_s0 frees the GPU; prefill spends
23,719 rows × 4 = ~94.9k sim steps of env.steps):

    cd ~/workspace/r2dreamer && MUJOCO_GL=egl \
      GENESIS_PICKAPLACE_ROOT=/home/j/workspace/genesis_pickaplace \
      nohup setsid ./.venv/bin/python train.py env=genesis_pick_v2 \
      env.demo_dir=/home/j/workspace/dreamerv3-torch/demonstrations/genesis_pick \
      env.env_num=8 env.steps=3.1e6 buffer.max_size=7e5 \
      trainer.pretrain=1000 seed=0 logdir=runs/pick_v2_s0 \
      > runs/pick_v2_s0/run.log 2>&1 &

Watch: train/action_entropy (must NOT ratchet), train/value_replay_mean (must
stay ≤ ~1), train/data/reward_frames (~3+), episode/train_picked, and eval the
periodic save_every checkpoints — not just the final one.
