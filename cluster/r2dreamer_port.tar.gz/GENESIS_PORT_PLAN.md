# Genesis pick env — port plan for r2dreamer

Port of the `genesis_pickaplace` env (source semantics: `~/workspace/dreamerv3-torch/envs/genesis.py`
+ `envs/genesis_vec.py`) into r2dreamer. Target task: `genesis_pick` — 64x64x6 two-camera image obs,
7-dim continuous joint actions, scope='pick', time_limit 1200, demo prefill from
`~/workspace/dreamerv3-torch/demonstrations/genesis_pick/*.npz`.

## 1. Env registration

- Factory: `envs/__init__.py:make_envs(config)` → suite = `config.task.split("_", 1)[0]`;
  per-env construction in `make_env(config, id)` (line 55). Add a `genesis` branch there that
  instantiates a new `envs/genesis.py:GenesisPick` (ported from the dv3 adapter), then falls through
  to the shared `wrappers.TimeLimit(env, config.time_limit // config.action_repeat)` + `wrappers.Dtype`.
- Required env API (model: `envs/metaworld.py:MetaWorld`):
  - subclass `gymnasium.Env` (r2dreamer's `TimeLimit` is a `gym.Wrapper`; the dv3 adapter is a plain
    class on old `gym` — must be rebased on gymnasium spaces).
  - `reset(**kwargs) -> obs_dict` (bare dict, no `(obs, info)` tuple).
  - `step(action) -> (obs_dict, reward, done, info)` — old 4-tuple, done = terminated or truncated.
  - `observation_space` = `gym.spaces.Dict` with `image: Box(0,255,(64,64,6),uint8)` and the
    `log_*: Box(-inf,inf,(1,),f32)` keys; `action_space` = `Box(-1,1,(7,),f32)` (no `.discrete` attr
    → `Dreamer.__init__` picks the continuous `bounded_normal` actor dist, dreamer.py:45-54).
  - Every obs (reset AND step) must carry `is_first`/`is_last`/`is_terminal` bools plus the same key
    set every step — `parallel.py:step` does `np.stack` over obs keys (line 67).
  - Do NOT put `reward` in the obs dict: `ParallelEnv.step` injects `reward` itself from the step
    return (parallel.py line 75) and zeroes it on reset rows.
- Keep the dv3 adapter's Genesis constraints verbatim: lazy `_build()` on first `reset()` (the
  constructor lambda is cloudpickled into a spawn worker, `parallel.py:Parallel`; `gs.init` must run
  in the worker, once per process); `FullTaskEnv(backend='cpu', max_steps=10**9, camera_rig=True,
  scope='pick')` so the env never self-truncates — episode length is owned by r2dreamer's TimeLimit,
  which sets `obs["is_last"]=True` + `info["discount"]=1.0` on timeout (wrappers.py:18-24).
  `is_terminal` fires only on true termination (nested / tip rule), which is what feeds the cont
  head (`cont = 1 - is_terminal`, dreamer.py:431).
- Episode boundary flow: `trainer.begin` keeps a per-env `done` mask; on done, `ParallelEnv.step`
  calls `e.reset()` instead of `step` (parallel.py:55) so the next row is the reset obs with
  `is_first=True`; actions are masked after done (`trans["action"] = act * ~done`, trainer.py:161).
  `episode` ids are CONSTANT per env slot (`torch.arange(env_num)`, trainer.py:116-118) — the
  SliceSampler (traj_key="episode") slices across episode boundaries and the RSSM resets state via
  `is_first` (`rssm.obs_step` zeroes stoch/deter/prev_action where reset, rssm.py:161-165).
- Seed each worker with `config.seed + id`, as the other suites do.
- Skip the genesis_vec batched-world path for v1 (its promise protocol targets dv3's
  `tools.simulate` two-pass loop, which r2dreamer doesn't have). `env_num` separate CPU worlds via
  `ParallelEnv` is the direct fit; 8-16 workers is the known sweet spot on this box.

## 2. The 6-channel image

- No code change needed in the encoder: `MultiEncoder` takes channels from the obs space
  (`input_ch = sum(v[-1] ...)`, networks.py:117) and `ConvEncoder` builds from `input_shape`
  (networks.py:196). `Dreamer.preprocess` (`image/255`, dreamer.py:570) is channel-agnostic.
- Decoder: only constructed when `model.rep_loss == "dreamer"` (dreamer.py:78-87), and even then
  `MultiDecoder` derives channels from the shapes dict; the `(3,64,64)` default in
  `ConvDecoder.__init__` (networks.py:238) is always overridden. Decoder-free `r2dreamer` /
  `infonce` / `dreamerpro` need nothing.
- ONE real 3-channel assumption: `tools.Logger.write` video path (tools.py:194-200) reshapes
  `(B,T,H,W,C)` and calls `add_video` with C channels — TensorBoard requires C in {1,3}, so
  `train_video`/`eval_video` break with C=6. Minimal fix (in `Logger.write`): if C==6, hsplit into
  two 3-channel views and concat along W (`np.concatenate([v[...,:3], v[...,3:]], axis=3)`) —
  gives top‖wrist side-by-side, matching the dv3 rig order.
- `dreamerpro`'s `random_translate` augment is channel-generic (permutes only), fine if ever used.

## 3. Demo / offline ingestion — DOES NOT EXIST, minimal insertion point

Neither `buffer.py` nor `train.py` has any offline/prefill support (grep for demo/offline: none).

- Insertion point: `train.py` between `agent = Dreamer(...)` (line 45) and
  `policy_trainer.begin(agent)` (line 52) — a new `prefill_from_npz(replay_buffer, agent, config)`
  (new file `demo_prefill.py` or a function in train.py), gated on a new `env.demo_dir` config key.
- Buffer format contract (from `Buffer.add_transition` + `Buffer.sample` + trainer.begin:158-167):
  each call extends a TensorDict of batch_size `(B,)` (lifted to `(B,1)`), B = **exactly
  `env_num`** — `LazyTensorStorage(ndim=2)` fixes the column count at the FIRST extend, and online
  collection later extends with `env_num` columns; a mismatch crashes. Required keys per row:
  - `image` uint8 (64,64,6); `reward` f32; `is_first`/`is_last`/`is_terminal` bool;
  - `action` f32 (7,) — stored convention = "action that produced this obs" (trainer.py:159-161;
    `Buffer.sample` re-shifts by one, buffer.py:41). The npz files use the SAME convention
    (zero action on the is_first frame), so actions load as-is.
  - `stoch` (32,16) f32 and `deter` (2048,) f32 — demo frames have no latents; seed with
    `agent.rssm.initial(B)` zeros. Safe because these are only the slice-context initial state and
    `Dreamer.update` refreshes them in-place after every sample (`replay_buffer.update`,
    dreamer.py:346) — same staleness mechanism as old online data.
  - `episode` int32 = column index (`arange(env_num)`), matching the trainer's constant slot ids.
- Loading scheme: read all `genesis-*.npz` (keys image/action/reward/discount/is_first/is_last/
  is_terminal/logprob; drop `discount`+`logprob`), pack demos round-robin into `env_num` streams
  back-to-back (is_first marks boundaries), equalize stream lengths by looping demos, then feed
  row-by-row: `buffer.add_transition(TensorDict(row, batch_size=(env_num,)))`.
- Side effects to account for: `trainer.begin` starts at `step = buffer.count() * action_repeat`
  (trainer.py:110) — prefill consumes the `steps` budget (bump `env.steps` by the prefill size) and
  makes the update condition (line 170) true immediately; set `trainer.pretrain` (e.g. 1000) to get
  a burst of updates on demos before acting. Demos are never re-added, so at `buffer.max_size` they
  are eventually evicted by FIFO — for persistent demo mixing, size the buffer so demos fit
  (~30-80k demo frames) and note eviction as a follow-up (no ring-fencing in torchrl storage).
- Memory: default `buffer.storage_device = cuda` and `max_size 5e5`; at 64x64x6 uint8 + 2048-d
  deter that is ~17 GB VRAM. Set `buffer.storage_device: cpu` (the cpu→cuda pin_memory path already
  exists, buffer.py:33-35) or `buffer.max_size: 2e5`.

## 4. Config draft

New `configs/env/genesis_pick.yaml` (fields mirror what `make_env`/trainer consume):

```yaml
task: 'genesis_pick'
steps: 1.01e6            # + prefill count, see §3
env_num: 8               # one Genesis CPU world per spawn worker; 16 max on this box
eval_episode_num: 0      # eval builds eval_episode_num EXTRA worlds (envs/__init__.py:16) — start 0
action_repeat: 1         # demo npz frames are single env steps; repeat>1 breaks demo alignment
train_ratio: 512         # tune down (e.g. 128) if 8 slow CPU envs starve the GPU
time_limit: 1200

seed: ${seed}
device: ${device}

size: [64, 64]
scope: 'pick'            # passed to FullTaskEnv(scope=...)
demo_dir: null           # set to /home/j/workspace/dreamerv3-torch/demonstrations/genesis_pick

encoder:
  mlp_keys: '$^'
  cnn_keys: 'image'
decoder:                 # unused unless model.rep_loss=dreamer, but the group is referenced
  mlp_keys: '$^'
  cnn_keys: 'image'
```

Launch: `python3 train.py env=genesis_pick model.rep_loss=r2dreamer buffer.storage_device=cpu`
(`rep_loss` lives in `configs/model/_base_.yaml`; options r2dreamer/dreamer/infonce/dreamerpro).
Tuning flag: `model.horizon: 333` → discount 1-1/333; with 1200-step episodes and sparse staged
reward, gamma^(steps-to-reward) may be invisible (see memory note) — try `model.horizon: 1000`.
Also consider `batch_length: 96` (memory note: barely-explored lever).

## 5. Logging: stage keys + diagnostics

- Eval path: `trainer.eval` auto-aggregates any obs key starting with `log_` by SUMMING per step
  and logs `episode/eval_<name>` (trainer.py:70-83); only `log_success` is clipped to 1. Therefore
  the adapter should emit `log_picked/log_placed/log_contact/log_nested/log_tipped/
  log_task_success` as 0.0 on every step EXCEPT the final one (`is_last`), where it emits the
  stage predicate from `info` — sums then equal the episode-end flags with no trainer change.
  (Encoder ignores them: `not k.startswith("log_")`, networks.py:107.)
- Train path: `trainer.begin` logs only `episode/score`/`episode/length` at done (lines 128-138) —
  it does NOT aggregate `log_*`. Since eval starts disabled (world cost), add a small patch in that
  done-block: read `trans` `log_*` values for the finished slot and `logger.scalar
  ("episode/train_<name>", ...)`. This is the equivalent of dv3's per-episode stage metrics (and
  avoids the "tip counted as success" proxy bug — `log_task_success` = nested only).
- Video/diagnostics without a decoder: `train_video` (slot-0 episode, trainer.py:131-134) and
  `eval_video` work once the 6-channel Logger fix (§2) lands. There is NO openl equivalent
  decoder-free: `Dreamer.video_pred` raises unless `rep_loss == "dreamer"` (dreamer.py:284-285), so
  keep `trainer.video_pred_log: False` (default). Numeric substitutes: `train/loss/*`, `train/con`,
  `train/rew`, `train/ret` scalars → `metrics.jsonl` + tensorboard (`tools.Logger`). No wandb in
  r2dreamer — optional later add for the standing eval-video directive.

## 6. Runtime / venv

- `pyproject.toml` pins: `requires-python >=3.11,<3.12`, torch 2.8.0, torchrl 0.9.2,
  tensordict 0.9.1, numpy 1.26.0, gymnasium 1.2.0, hydra-core 1.3.2, ruamel.yaml 0.17.4.
- Our `.venv-eval` (measured): python 3.10.12, torch 2.7.0+cu126, numpy 2.2.6, gymnasium 1.2.3.
  **Conflicts: python minor version (3.10 < 3.11 hard pin), torch 2.7 vs 2.8, numpy 2.2 vs 1.26.**
  torchrl 0.9.x/tensordict 0.9.x are release-paired with torch 2.8 — `.venv-eval` cannot run
  r2dreamer as pinned.
- Extra constraint: `ParallelEnv` spawn workers use the SAME interpreter, so genesis-world 0.2.1
  (editable → `~/workspace/Genesis`, +local headless patch, NOT pip-reproducible) must be
  importable in whatever venv runs `train.py`.
- Recommendation: NEW dedicated venv, python 3.11 (taichi 1.7 has cp311 wheels), pip-only (never
  conda — see cluster poisoning incident): `pip install -e ~/workspace/r2dreamer` then
  `pip install -e ~/workspace/Genesis` and resolve numpy (genesis 0.2.1 tolerates 1.26).
  Fallback if genesis won't build on 3.11: try py3.10 + torch 2.7 + torchrl 0.8.x/tensordict 0.8.x
  — but the `LazyTensorStorage(ndim=2)`/`SliceSampler` API surface across that downgrade is
  unverified; treat as experiment, not plan of record.

## 7. Build order + verification checkpoints

1. **Venv gate**: build py3.11 venv; `python -c "import torch, torchrl, tensordict, genesis"`.
   Then `python train.py env=dmc_proprio env.steps=2000 env.env_num=2` sanity (needs dmc extra) —
   or skip straight to 2 if no dmc install.
2. **Adapter import test**: add `envs/genesis.py` + factory branch + `configs/env/genesis_pick.yaml`;
   single-process check (no ParallelEnv): construct env, reset, assert obs keys/shapes/dtypes
   (image (64,64,6) uint8), step 20 random actions.
3. **100-step smoke**: `train.py env=genesis_pick env.env_num=2 env.steps=500 buffer.storage_device=cpu
   trainer.eval_every=1e9` — verifies spawn-worker Genesis build, encoder prints
   `Encoder CNN shapes: {'image': (64,64,6)}`, transitions land in buffer, one `agent.update` runs.
4. **Demo-prefill check**: run prefill alone (script mode): load npz dir, extend buffer, then
   `buffer.sample()` — assert shapes `(16, 65, ...)`, actions shifted, `is_first` present in slices;
   then a 500-step run with `env.demo_dir` set + `trainer.pretrain=100` and confirm loss curves move
   during pretrain before env stepping.
5. **Video/logging check**: force one episode end; confirm `episode/train_picked` etc. scalars and
   the 6→3+3 stitched `train_video` in tensorboard.
6. **Short training run**: 50-100k steps, `model.rep_loss=r2dreamer`, env_num 8, watch
   `episode/train_picked` and `train/con`; compare wall-clock vs dv3 (r2dreamer claims ~5x).
   Then the H4 leg: same run with/without demo prefill, x3 seeds, honesty protocol (neg control =
   prefill with shuffled actions).
