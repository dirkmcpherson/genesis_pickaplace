"""Genesis pick-and-place suite for r2dreamer (task: genesis_pick).

Wraps genesis_pickaplace's FullTaskEnv (staged sparse reward, [-1,1]^7 joint
actions, 64x64x6 two-camera rig obs: overhead RGB ++ wrist RGB). Ported from
the dv3 adapter (~/workspace/dreamerv3-torch/envs/genesis.py), rebased on
gymnasium + the metaworld adapter's API: bare-dict reset, old 4-tuple step,
is_first / is_last / is_terminal in every obs.

Genesis constraints honored here (keep these verbatim):
  - gs.init exactly once per process, world built ONCE and reused across
    episodes. LAZY _build() on first reset(): under ParallelEnv the constructed
    adapter is cloudpickled into a spawn worker -- the world must be built in
    the WORKER, never in the parent. Nothing genesis-related is imported at
    module load, and observation_space/action_space are static (readable from
    the parent proxy without triggering a build).
  - FullTaskEnv gets max_steps=10**9 so it never self-truncates (and never
    runs its internal settle mid-episode); episode length is owned by
    r2dreamer's wrappers.TimeLimit(config.time_limit), which sets
    obs['is_last']=True + info['discount']=1.0 on timeout. is_terminal fires
    ONLY on true task termination (scope='pick': picked; plus the tip rule).

Logging contract: trainer.eval SUMS log_* obs keys per step, so the stage
flags are emitted as 0.0 on every step EXCEPT the episode-final one, where
they carry the episode-cumulative predicates (from FullTaskEnv._granted +
info). Known blind spot: a TimeLimit truncation happens OUTSIDE this adapter,
so a truncated episode reports all-zero log_* -- exact for picked/tipped in
scope='pick' (either would have terminated), only pre-pick goal contact can
be under-reported.
"""
import os

import gymnasium as gym
import numpy as np

REPO = os.environ.get("GENESIS_PICKAPLACE_ROOT", "/home/j/workspace/genesis_pickaplace")

STAGE_KEYS = ("picked", "placed", "contact", "nested", "tipped")
# scope='place' adds one stage key + redefines success (scope-GATED: the pick
# obs-space/key set is byte-identical to before the place work).
PLACE_EXTRA_KEYS = ("placed_v2",)


class GenesisPick(gym.Env):
    # delta_joint mode: rad per SIM step per arm dim for a full-scale action.
    # Calibrated 2026-08-10 on episodes_pick_pruned_img (118,194 frames),
    # COMMANDED-target deltas (the demo encoding): global p99 |dcmd| = 0.0249,
    # max per-dim p99 = 0.0307 (joint 4); 0.04 clips only 0.17% of demo
    # per-frame deltas (max ever 0.059). MUST match the converter's --delta-cap
    # (to_dreamer_demos.py --action-encoding delta_joint).
    DELTA_CAP = 0.04
    DELTA_LEASH_MULT = 3.0  # target leashed to measured qpos within 3*cap = 0.12
                            # (mirrors CartesianCanEnv's setpoint leash); covers
                            # the demos' |cmd - q| PD lead (p99 = 0.126)

    def __init__(self, task="pick", size=(64, 64), seed=0, scope="pick",
                 place_shaping=False, place_entry_bank=None, action_repeat=1,
                 reward_scale=1.0, action_mode="absolute", delta_cap=None,
                 delta_leash_mult=None):
        self._task = task
        self._size = tuple(size)
        self._seed = seed
        self._scope = scope
        # Action mode (env.action_mode): 'absolute' (default, byte-identical to
        # every prior run) = action IS the normalized joint target. 'delta_joint'
        # = arm dims in [-1,1] are per-SIM-step joint-target DELTAS (a*cap rad,
        # integrated onto a persistent target initialized from measured qpos at
        # reset, clipped to the ARM_LO/HI envelope, and leashed to measured qpos
        # within DELTA_LEASH_MULT*cap so the error can never run away); grip dim
        # stays ABSOLUTE ([-1,1] -> 0..1). Motivation (MANISKILL_VS_GENESIS #4):
        # the working MS run used pd_ee_delta_pos -- delta-position targets are
        # self-correcting under entropy noise (mean-reverting hover), while
        # absolute joint targets turn sampled-action exploration into arm thrash.
        # Under action_repeat N the target integrates a*cap EACH sim step, so an
        # agent-step action a moves the target N*a*cap -- exactly what the demo
        # converter + demo_prefill's mean-pooled downsample encode.
        assert action_mode in ("absolute", "delta_joint"), action_mode
        self._action_mode = action_mode
        self._delta_cap = float(delta_cap if delta_cap is not None else self.DELTA_CAP)
        # Leash mult is configurable so cap and leash decouple: the cap bounds
        # per-step SPEED (policy-facing), the leash bounds |target - qpos| and
        # must stay >= the demos' ABSOLUTE PD lead (p99 0.126 rad) or demo
        # replay is clipped. E.g. cap 0.025 needs mult 5 (0.125) where cap 0.04
        # needed only 3 (0.12).
        self._delta_leash_mult = float(
            delta_leash_mult if delta_leash_mult is not None else self.DELTA_LEASH_MULT)
        # Action repeat INSIDE the adapter (dmc/metaworld style): one agent
        # step = N sim steps holding the same action, rewards summed, early
        # break on termination. Default 1 = byte-identical to the old behavior
        # (existing runs/configs unaffected). Demos MUST be downsampled by the
        # same factor (env.demo_downsample) or the world model learns
        # contradictory dynamics from demos vs rollouts.
        self._action_repeat = int(action_repeat)
        # Reward-scale lever (env.reward_scale, default 1.0 = old behavior):
        # multiplies EVERY env-side reward. Motivation (R2D_PICK_DIAGNOSIS #2):
        # the symexp_twohot reward head leaks ~0.005/state on zero-reward data;
        # at scale 1 the sparse +1 pick terminal is the same order as the leak
        # integrated over the horizon. Scaling the true reward (e.g. 100x) puts
        # the real signal orders of magnitude above the leak; the return
        # normalizer's percentile scaling absorbs the magnitude. demo_prefill
        # applies the SAME factor to demo rewards -- the reward function must
        # stay coherent between online and demo rows.
        self._reward_scale = float(reward_scale)
        # TRAINING-ONLY place-scope shaping (FullTaskEnv shaping=): dense
        # potential-based term + step cost. log_placed_v2 / log_task_success
        # stay the honest sparse metric regardless.
        self._place_shaping = bool(place_shaping)
        # scope='place' entry bank path (FullTaskEnv entry_bank=). None keeps
        # the legacy single-entry-per-demo pick_entry_states.json; a DENSE bank
        # (place_entry_states_dense.json) is sampled uniformly over entries.
        self._place_entry_bank = place_entry_bank
        self._env = None  # lazy: built on first reset, inside the spawn worker
        self.reward_range = [-np.inf, np.inf]
        self._stage_keys = STAGE_KEYS + (PLACE_EXTRA_KEYS if scope == "place" else ())

    def _build(self):
        import sys

        for p in (f"{REPO}/baselines", f"{REPO}/baselines/rl", f"{REPO}/can_pos_recovery"):
            if p not in sys.path:
                sys.path.insert(0, p)
        from full_env import FullTaskEnv
        import pick_env as _pe

        # delta_joint machinery (bound lazily: module-load stays genesis-free)
        self._pe_normalize = _pe.normalize_action
        self._arm_lo, self._arm_hi = _pe.ARM_LO.copy(), _pe.ARM_HI.copy()
        self._env = FullTaskEnv(
            backend="cpu",
            max_steps=10**9,
            scope=self._scope,
            render_size=self._size,
            camera_rig=True,
            shaping=self._place_shaping,
            # getattr: instances pickled before this attr existed must still build
            entry_bank=getattr(self, "_place_entry_bank", None),
        )
        self._env.reset(seed=self._seed)

    def _image(self):
        # (64,64,6) uint8: topB overhead RGB ++ through-gripper wrist RGB --
        # channel order MUST match the dv3 demo rig (stage-2 prefill mixes them).
        return self._env.genv.rig_obs()

    @property
    def observation_space(self):
        spaces = {
            "image": gym.spaces.Box(0, 255, self._size + (6,), dtype=np.uint8),
        }
        for k in self._stage_keys + ("task_success",):
            spaces[f"log_{k}"] = gym.spaces.Box(-np.inf, np.inf, (1,), dtype=np.float32)
        return gym.spaces.Dict(spaces)

    @property
    def action_space(self):
        # Plain Box, NO .discrete attribute: Dreamer.__init__ does
        # hasattr(act_space, "discrete") -- setting discrete=False would still
        # route to the onehot dist. Absence selects the continuous
        # bounded_normal actor.
        return gym.spaces.Box(-1.0, 1.0, (7,), dtype=np.float32)

    def sync_delta_target(self):
        """(Re-)initialize the delta_joint persistent target from measured qpos.

        Called by reset(); MUST also be called by any external code that resets
        the inner env directly (eval_genesis.reset_to_uid bypasses adapter
        reset), or the target carries over from the previous episode. No-op in
        absolute mode."""
        if getattr(self, "_action_mode", "absolute") != "delta_joint" or self._env is None:
            return
        q = np.asarray(self._env.genv._obs()["state"][:6], dtype=np.float64)
        self._dj_target = q.copy()
        self._dj_qmeas = q.copy()

    def reset(self, **kwargs):
        if self._env is None:
            self._build()
        self._env.reset()
        self.sync_delta_target()
        obs = {
            "is_first": True,
            "is_last": False,
            "is_terminal": False,
            "image": self._image(),
        }
        for k in self._stage_keys + ("task_success",):
            obs[f"log_{k}"] = np.float32(0.0)
        # NO 'reward' key: ParallelEnv.step injects reward itself from the
        # step return and zeroes it on reset rows.
        return obs

    def step(self, action):
        a = np.asarray(action, dtype=np.float32)
        assert np.isfinite(a).all(), a
        # getattr: instances pickled before action_repeat existed must still run
        repeat = getattr(self, "_action_repeat", 1)
        reward = 0.0
        if getattr(self, "_action_mode", "absolute") == "delta_joint":
            # Integrate a*cap onto the persistent joint target EACH sim step
            # (ramped targets, like the 30 Hz demos), leashed to measured qpos.
            # getattr: instances pickled before delta_leash_mult existed must still run
            cap = self._delta_cap
            leash = getattr(self, "_delta_leash_mult", self.DELTA_LEASH_MULT) * cap
            d = np.clip(a[:6].astype(np.float64), -1.0, 1.0) * cap
            grip01 = (float(np.clip(a[6], -1.0, 1.0)) + 1.0) / 2.0  # grip ABSOLUTE
            for _ in range(repeat):
                sp = np.clip(self._dj_target + d, self._arm_lo, self._arm_hi)
                self._dj_target = self._dj_qmeas + np.clip(
                    sp - self._dj_qmeas, -leash, leash)
                phys = np.concatenate([self._dj_target, [grip01]])
                state, r, terminated, truncated, info = self._env.step(
                    self._pe_normalize(phys).astype(np.float32))
                self._dj_qmeas = np.asarray(state[:6], dtype=np.float64)
                reward += float(r)
                if terminated or truncated:
                    break
        else:
            for _ in range(repeat):
                _state, r, terminated, truncated, info = self._env.step(a)
                reward += float(r)
                if terminated or truncated:
                    break
        # getattr: instances pickled before reward_scale existed must still run
        reward *= float(getattr(self, "_reward_scale", 1.0))
        done = bool(terminated or truncated)  # truncated never fires (max_steps=1e9)
        obs = {
            "is_first": False,
            "is_last": done,
            "is_terminal": bool(terminated),
            "image": self._image(),
        }
        # Stage flags: zero on every step except the final one (trainer.eval
        # SUMS log_* per step). Episode-cumulative record = env._granted
        # (staged-reward grants); 'tipped' only ever appears on the
        # terminating step's info.
        for k in self._stage_keys:
            hit = done and (k in self._env._granted or bool(info.get(k)))
            obs[f"log_{k}"] = np.float32(float(hit))
        # task_success: scope='place' -> placed_v2 (the scope's own terminal
        # predicate); otherwise nested only (NOT bare early-termination, which
        # would count tip-outs as successes -- the dv3 proxy bug).
        success_key = "placed_v2" if self._scope == "place" else "nested"
        obs["log_task_success"] = np.float32(
            float(done and (success_key in self._env._granted
                            or bool(info.get(success_key))))
        )
        return obs, np.float32(reward), done, info

    def render(self):
        return self._image()

    def close(self):
        pass
