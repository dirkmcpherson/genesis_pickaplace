import atexit

from . import parallel, wrappers


def make_envs(config):
    suite = config.task.split("_", 1)[0]

    if suite == "isaaclab":
        return _make_isaaclab_envs(config)

    def env_constructor(idx):
        return lambda: make_env(config, idx)

    train_envs = parallel.ParallelEnv(env_constructor, config.env_num, config.device)
    eval_envs = (
        parallel.ParallelEnv(env_constructor, config.eval_episode_num, config.device)
        if config.eval_episode_num > 0
        else None
    )
    obs_space = train_envs.observation_space
    act_space = train_envs.action_space
    return train_envs, eval_envs, obs_space, act_space


def _make_isaaclab_envs(config):
    if int(config.eval_episode_num) > 0:
        raise ValueError(
            "IsaacLab environments do not support separate eval envs yet. Set eval_episode_num: 0 in the env config."
        )

    # AppLauncher must be created before any isaaclab.* module is imported.
    from isaaclab.app import AppLauncher

    headless = getattr(config, "headless", True)
    launcher = AppLauncher(headless=headless, enable_cameras=True)
    sim_app = launcher.app

    from envs.isaaclab import IsaacLabVecEnv, create_isaaclab_env

    raw_env = create_isaaclab_env(config)

    train_envs = IsaacLabVecEnv(raw_env, simulation_app=sim_app, image_size=tuple(config.size))

    # Ensure the SimulationApp is shut down cleanly on process exit.
    atexit.register(train_envs.close)

    eval_envs = None  # Not supported yet for IsaacLab.

    obs_space = train_envs.observation_space
    act_space = train_envs.action_space
    return train_envs, eval_envs, obs_space, act_space


def make_env(config, id):
    suite, task = config.task.split("_", 1)
    if suite == "dmc":
        import envs.dmc as dmc

        env = dmc.DeepMindControl(task, config.action_repeat, config.size, seed=config.seed + id)
        env = wrappers.NormalizeActions(env)
    elif suite == "atari":
        import envs.atari as atari

        env = atari.Atari(
            task,
            config.action_repeat,
            config.size,
            gray=config.gray,
            noops=config.noops,
            lives=config.lives,
            sticky=config.sticky,
            actions=config.actions,
            length=config.time_limit,
            pooling=config.pooling,
            aggregate=config.aggregate,
            resize=config.resize,
            autostart=config.autostart,
            clip_reward=config.clip_reward,
            seed=config.seed + id,
        )
        env = wrappers.OneHotAction(env)
    elif suite == "memorymaze":
        from envs.memorymaze import MemoryMaze

        env = MemoryMaze(task, seed=config.seed + id)
        env = wrappers.OneHotAction(env)
    elif suite == "crafter":
        import envs.crafter as crafter

        env = crafter.Crafter(task, config.size, seed=config.seed + id)
        env = wrappers.OneHotAction(env)
    elif suite == "metaworld":
        import envs.metaworld as metaworld

        env = metaworld.MetaWorld(
            task,
            config.action_repeat,
            config.size,
            config.camera,
            config.seed + id,
        )
    elif suite == "genesis":
        import envs.genesis as genesis

        env = genesis.GenesisPick(
            task,
            size=tuple(config.size),
            seed=config.seed + id,
            scope=config.scope,
            # TRAINING-ONLY dense shaping for scope='place' (FullTaskEnv
            # shaping=); default false, honest metric stays placed_v2.
            place_shaping=config.get("place_shaping", False),
            # scope='place' entry bank path; null -> legacy single-entry bank
            place_entry_bank=config.get("place_entry_bank", None),
            # one agent step = N sim steps (rewards summed, early break on
            # termination); demos must be downsampled by the same factor
            # (env.demo_downsample -- demo_prefill asserts the match).
            action_repeat=config.action_repeat,
            # multiplies env-side rewards; demo_prefill applies the SAME
            # factor to demo rewards (env.reward_scale, default 1.0).
            reward_scale=config.get("reward_scale", 1.0),
            # 'absolute' (default) | 'delta_joint': arm dims are per-SIM-step
            # joint-target deltas (a*delta_cap rad) integrated onto a leashed
            # persistent target; grip stays absolute. Demos MUST be delta-
            # encoded with the SAME cap (to_dreamer_demos --action-encoding
            # delta_joint --delta-cap).
            action_mode=config.get("action_mode", "absolute"),
            delta_cap=config.get("delta_cap", None),
            # leash stays ABSOLUTE-calibrated (demos' PD lead p99 0.126 rad):
            # smaller caps need a larger mult (cap 0.025 -> 5, cap 0.04 -> 3)
            delta_leash_mult=config.get("delta_leash_mult", None),
        )
    else:
        raise NotImplementedError(suite)
    env = wrappers.TimeLimit(env, config.time_limit // config.action_repeat)
    return wrappers.Dtype(env)
