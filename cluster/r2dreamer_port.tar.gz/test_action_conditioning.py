"""Runtime proof: how Dreamer.act consumes the previous action.

Claims to test against runs/genesis_pick_demo_s0/latest.pt (real weights, CPU,
no Genesis world -- GenesisPick spaces are static):

  P1  The transition dict's "action" key is IRRELEVANT to act(): adding a
      garbage action key to the trans changes nothing (bit-identical action
      and next state vs the no-action-key trans).
  P2  The previous action DOES condition the recurrent state -- but via
      state["prev_action"]: perturbing it changes the deter state and the
      resulting action.
  P3  eval_genesis's loop carries the actual previous action: act() returns
      prev_action=<the action it just emitted>, and obs_step zeroes
      prev_action only when is_first=True (t=0), matching training.
  P4  Sampling parity: act(eval=False) == actor(feat).rsample() (the training
      collector path, trainer.py:205) under an identical RNG state, and
      act(eval=True) == actor(feat).mode.
"""
import os, pathlib, sys

os.environ.setdefault("GENESIS_PICKAPLACE_ROOT", "/home/j/workspace/genesis_pickaplace")
HERE = pathlib.Path("/home/j/workspace/r2dreamer")
sys.path.insert(0, str(HERE))

import numpy as np
import torch
from omegaconf import OmegaConf
from tensordict import TensorDict

from dreamer import Dreamer
from envs.genesis import STAGE_KEYS, GenesisPick

RUN = HERE / "runs/genesis_pick_demo_s0"
cfg = OmegaConf.load(RUN / ".hydra/config.yaml")
cfg.device = "cpu"
cfg.model.compile = False

env = GenesisPick("pick", size=tuple(cfg.env.size), seed=0, scope=str(cfg.env.scope))
agent = Dreamer(cfg.model, env.observation_space, env.action_space).to("cpu")
ck = torch.load(RUN / "latest.pt", map_location="cpu", weights_only=False)
missing, unexpected = agent.load_state_dict(ck["agent_state_dict"], strict=False)
assert not any(k.startswith(("actor.", "rssm.", "encoder.")) for k in missing)
agent.clone_and_freeze()
agent.requires_grad_(False)
agent.eval()

rng = np.random.RandomState(0)


def mk_trans(with_action=None):
    obs = {
        "is_first": False, "is_last": False, "is_terminal": False,
        "image": img,
    }
    for k in STAGE_KEYS + ("task_success",):
        obs[f"log_{k}"] = np.float32(0.0)
    d = {k: torch.as_tensor(np.asarray(v)[None]) for k, v in obs.items()}
    d["reward"] = torch.tensor([0.0], dtype=torch.float32)
    if with_action is not None:
        d["action"] = torch.as_tensor(with_action[None])
    td = TensorDict(d, batch_size=(1,), device="cpu")
    for k in td.keys():
        if td[k].ndim == 1:
            td[k] = td[k].unsqueeze(-1)
    return td


img = rng.randint(0, 256, (64, 64, 6), dtype=np.uint8)
prev_a = rng.uniform(-1, 1, 7).astype(np.float32)

state = agent.get_initial_state(1)
state["prev_action"] = torch.as_tensor(prev_a[None])

# ---- P1: trans action key irrelevant ----
torch.manual_seed(123)
a1, s1 = agent.act(mk_trans(), state.clone(), eval=True)
torch.manual_seed(123)
garbage = np.full(7, 9.9, dtype=np.float32)
a2, s2 = agent.act(mk_trans(with_action=garbage), state.clone(), eval=True)
assert torch.equal(a1, a2), "P1 FAIL: trans['action'] changed the emitted action"
assert torch.equal(s1["deter"], s2["deter"]) and torch.equal(s1["stoch"], s2["stoch"]), \
    "P1 FAIL: trans['action'] changed the recurrent state"
print("P1 PASS: trans 'action' key (absent vs garbage 9.9s) -> bit-identical action & state")

# ---- P2: state prev_action conditions the RSSM ----
state_z = state.clone(); state_z["prev_action"] = torch.zeros(1, 7)
torch.manual_seed(123)
a3, s3 = agent.act(mk_trans(), state_z, eval=True)
d_deter = (s1["deter"] - s3["deter"]).abs().max().item()
d_act = (a1 - a3).abs().max().item()
assert d_deter > 0, "P2 FAIL: prev_action does not condition deter"
print(f"P2 PASS: perturbing state['prev_action'] -> max|d_deter|={d_deter:.4g}, max|d_action|={d_act:.4g}")

# ---- P3: act returns its own action as prev_action; is_first zeroes it ----
assert torch.equal(s1["prev_action"], a1), "P3 FAIL: returned state does not carry the emitted action"
# is_first=True must make prev_action irrelevant (zeroed inside obs_step).
# NOTE: preprocess mutates trans["image"] in place -> fresh trans per call
# (the real loops also build a fresh trans every step).
def mk_first():
    t = mk_trans(); t["is_first"] = torch.ones(1, 1, dtype=torch.bool); return t
torch.manual_seed(123)
a4, _ = agent.act(mk_first(), state.clone(), eval=True)    # prev_a garbage-ish
torch.manual_seed(123)
a5, _ = agent.act(mk_first(), state_z.clone(), eval=True)  # prev_action zeros
assert torch.equal(a4, a5), "P3 FAIL: is_first did not neutralize prev_action"
print("P3 PASS: act() returns emitted action as state['prev_action']; is_first=True zeroes it")

# ---- P4: sampling parity with the actor dist ----
# Reference replicates act()'s exact op order (obs_step's stoch rsample also
# consumes RNG, so seed before the WHOLE sequence, not just the actor sample).
def ref(sample):
    torch.manual_seed(7)
    t = mk_trans()
    embed = agent._frozen_encoder(agent.preprocess(t))
    st = state.clone()
    stoch, deter, _ = agent._frozen_rssm.obs_step(
        st["stoch"], st["deter"], st["prev_action"], embed, t["is_first"])
    feat = agent._frozen_rssm.get_feat(stoch, deter)
    dist = agent._frozen_actor(feat)
    return dist.rsample() if sample else dist.mode

a_ref = ref(sample=True)
torch.manual_seed(7)
a_act, _ = agent.act(mk_trans(), state.clone(), eval=False)
assert torch.equal(a_ref, a_act), "P4 FAIL: act(eval=False) != actor.rsample()"
a_mode_ref = ref(sample=False)
torch.manual_seed(7)
a_mode, _ = agent.act(mk_trans(), state.clone(), eval=True)
assert torch.equal(a_mode_ref, a_mode), "P4 FAIL: act(eval=True) != actor.mode"
assert not torch.equal(a_ref, a_mode), "P4 sanity: sample == mode?!"
print("P4 PASS: act(eval=False) == actor(feat).rsample() (RNG-matched); act(eval=True) == mode")

print("\nALL PROOFS PASS")
