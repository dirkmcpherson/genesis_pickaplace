#!/usr/bin/env python
"""Sync runs/*/metrics.jsonl scalar histories to wandb.

Target: entity jambotime, project r2dreamer_genesis; one wandb run per run dir,
named after the dir. The full step-keyed scalar history is uploaded via a
custom step metric "env_step" (define_metric), so non-monotonic step values
from relaunches/resumes never get dropped by wandb's internal-step rule.

Idempotent: a `.wandb_synced` JSON marker in each run dir records the wandb
run id + how many metrics.jsonl lines were synced. Re-running skips fully
synced runs and RESUMES (same run id) any run whose metrics.jsonl has grown,
appending only the new lines -- safe to run on a live training run.

Usage:
  ./.venv/bin/python sync_runs_to_wandb.py [--runs-dir runs] [--only NAME ...]
                                           [--force]  # re-upload from scratch
"""
import argparse
import json
import math
import pathlib
import sys

ENTITY = "jambotime"
PROJECT = "r2dreamer_genesis"
MARKER = ".wandb_synced"

HERE = pathlib.Path(__file__).resolve().parent


def load_hydra_config(run_dir):
    """Run's resolved hydra config as a plain dict (unresolved interpolations kept
    as literal '${...}' strings -- they need runtime context to resolve)."""
    p = run_dir / ".hydra" / "config.yaml"
    if not p.exists():
        return {}
    try:
        from omegaconf import OmegaConf
        return OmegaConf.to_container(OmegaConf.load(p), resolve=False)
    except Exception as e:
        print(f"  [warn] hydra config load failed ({e}); syncing without config")
        return {}


def sync_run(run_dir, force=False):
    import wandb

    metrics = run_dir / "metrics.jsonl"
    lines = metrics.read_text().splitlines()
    n_total = len(lines)

    marker_path = run_dir / MARKER
    state = {}
    if marker_path.exists() and not force:
        try:
            state = json.loads(marker_path.read_text())
        except Exception:
            state = {}
    n_done = int(state.get("lines", 0))
    run_id = state.get("run_id")

    if n_done >= n_total and run_id:
        print(f"  up to date ({n_total} lines) -> skip")
        return

    run = wandb.init(
        entity=ENTITY, project=PROJECT, name=run_dir.name,
        id=run_id, resume="allow" if run_id else None,
        job_type="train-sync", tags=["metrics-jsonl-sync"],
        config=load_hydra_config(run_dir),
        dir=str(run_dir),
        settings=wandb.Settings(console="off"),
    )
    try:
        run.define_metric("env_step")
        run.define_metric("*", step_metric="env_step")
        n_logged, n_bad = 0, 0
        for line in lines[n_done:]:
            line = line.strip()
            if not line:
                n_done += 1
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                n_bad += 1
                n_done += 1
                continue
            step = rec.pop("step", None)
            row = {k: v for k, v in rec.items()
                   if isinstance(v, (int, float)) and not isinstance(v, bool)
                   and math.isfinite(v)}
            if step is not None:
                row["env_step"] = step
            if row:
                run.log(row)
                n_logged += 1
            n_done += 1
            # checkpoint the marker occasionally so an interrupt resumes cleanly
            if n_done % 20000 == 0:
                marker_path.write_text(json.dumps(
                    {"run_id": run.id, "lines": n_done, "entity": ENTITY,
                     "project": PROJECT}))
        marker_path.write_text(json.dumps(
            {"run_id": run.id, "lines": n_done, "entity": ENTITY,
             "project": PROJECT}))
        print(f"  logged {n_logged} rows ({n_bad} unparsable) -> {run.url}")
    finally:
        run.finish()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs-dir", default=str(HERE / "runs"))
    ap.add_argument("--only", nargs="*", default=None,
                    help="run dir names to sync (default: all with metrics.jsonl)")
    ap.add_argument("--force", action="store_true",
                    help="ignore markers; re-upload every history from line 0 "
                         "(new wandb run unless the marker's run_id is kept)")
    args = ap.parse_args()

    runs_dir = pathlib.Path(args.runs_dir)
    dirs = sorted(d for d in runs_dir.iterdir()
                  if d.is_dir() and (d / "metrics.jsonl").exists())
    if args.only:
        dirs = [d for d in dirs if d.name in set(args.only)]
    if not dirs:
        sys.exit(f"no run dirs with metrics.jsonl under {runs_dir}")

    print(f"syncing {len(dirs)} runs -> {ENTITY}/{PROJECT}")
    failures = []
    for d in dirs:
        print(f"[{d.name}]")
        try:
            sync_run(d, force=args.force)
        except Exception as e:
            failures.append((d.name, e))
            print(f"  FAILED: {e}")
    if failures:
        print(f"\n{len(failures)} run(s) failed: {[n for n, _ in failures]}")
        sys.exit(1)
    print("\nall runs synced")


if __name__ == "__main__":
    main()
