"""Standalone policy eval for genesis_pick r2dreamer runs (dv3 genesis_eval.py equivalent).

Why a separate process: genesis allows ONE gs.init/world per process, so the
training process (eval_episode_num=0) can never evaluate in-process. This loads
a checkpoint (train.py's latest.pt: {"agent_state_dict", "optims_state_dict"})
into a FRESH process, builds a single in-process Genesis world (envs/genesis.py
adapter, scope from the run config -- 'pick'), rolls the policy out for N
episodes from DEMO ICs (FullTaskEnv.reset draws a success-labeled demo uid ->
that demo's recorded can placement; same reset distribution TRAINING uses), and
reports picked/tipped/timeout rates plus a top|wrist mp4 per episode.

Action selection mirrors Dreamer.act's own eval convention:
  --mode sample  -> action_dist.rsample()  (trainer's eval=False path; matches
                    the dv3 protocol headline numbers: eval SAMPLES)
  --mode mode    -> action_dist.mode       (trainer.eval's eval=True path)

Checkpoint caveat: train.py writes latest.pt ONLY at the end of the run
(trainer has no periodic save), so a still-running run dir has no latest.pt yet.

Usage:
  MUJOCO_GL=egl GENESIS_PICKAPLACE_ROOT=~/workspace/genesis_pickaplace \
    ./.venv/bin/python eval_genesis.py --checkpoint runs/<run>/latest.pt \
    --episodes 8 --max-steps 1200 [--mode sample] [--device cpu]
"""
import os

os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("GENESIS_PICKAPLACE_ROOT", "/home/j/workspace/genesis_pickaplace")

import argparse
import json
import pathlib
import sys
import time

import numpy as np

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

ap = argparse.ArgumentParser()
ap.add_argument("--checkpoint", default=str(HERE / "runs/genesis_pick_demo_s0/latest.pt"),
                help="latest.pt path (or a run dir containing one)")
ap.add_argument("--config", default=None,
                help="hydra-resolved config.yaml; default <run_dir>/.hydra/config.yaml "
                     "(MUST match the checkpoint's model dims)")
ap.add_argument("--episodes", type=int, default=8)
ap.add_argument("--max-steps", type=int, default=1200,
                help="env-step horizon per episode (training time_limit is 1200)")
ap.add_argument("--mode", choices=["sample", "mode"], default="sample",
                help="sample = actor rsample (dv3 protocol default); mode = deterministic")
ap.add_argument("--device", default="cpu",
                help="net device; default cpu because training owns the GPU")
ap.add_argument("--seed", type=int, default=0)
ap.add_argument("--out", default=None, help="output dir; default <run_dir>/policy_eval")
ap.add_argument("--scale", type=int, default=4, help="mp4 upscale factor (64px cams are tiny)")
ap.add_argument("--fps", type=float, default=0,
                help="video playback fps; 0 = real-time (30Hz sim / action_repeat, "
                     "i.e. 7.5 for repeat-4 -- frames are one per agent step)")
ap.add_argument("--torch-threads", type=int, default=4,
                help="cap torch CPU threads (training's 8 genesis workers share this box)")
ap.add_argument("--append-metrics", metavar="RUN_DIR", default=None,
                help="append the eval summary as one JSON line to "
                     "RUN_DIR/metrics.jsonl (keys eval/*, step = the checkpoint's "
                     "step). The run's wandb live-syncer then uploads it INTO the "
                     "TRAINING wandb run as a first-class curve (eval/picked vs "
                     "env_step) -- single wandb writer, no concurrent-resume "
                     "conflicts. Composes with --wandb (separate run keeps the "
                     "videos).")
ap.add_argument("--wandb", action="store_true",
                help="log summary metrics + up to 6 episode mp4s to wandb "
                     "(entity jambotime, project r2dreamer_genesis); never fatal")
args = ap.parse_args()

import torch  # noqa: E402

torch.set_num_threads(args.torch_threads)

from omegaconf import OmegaConf  # noqa: E402
from tensordict import TensorDict  # noqa: E402

import tools  # noqa: E402
from dreamer import Dreamer  # noqa: E402
from envs.genesis import STAGE_KEYS, GenesisPick  # noqa: E402

CKPT = pathlib.Path(args.checkpoint).expanduser().resolve()
if CKPT.is_dir():
    CKPT = CKPT / "latest.pt"
RUN_DIR = CKPT.parent
if not CKPT.exists():
    sys.exit(f"checkpoint not found: {CKPT}\n(train.py writes latest.pt only at run END; "
             f"a still-running run has no checkpoint yet)")
CFG_PATH = pathlib.Path(args.config) if args.config else RUN_DIR / ".hydra" / "config.yaml"
if not CFG_PATH.exists():
    sys.exit(f"config not found: {CFG_PATH} (pass --config)")
OUT = pathlib.Path(args.out) if args.out else RUN_DIR / "policy_eval"
OUT.mkdir(parents=True, exist_ok=True)

tools.set_seed_everywhere(args.seed)

cfg = OmegaConf.load(CFG_PATH)
cfg.device = args.device          # ${device} interpolations (model/rssm/heads) follow
cfg.model.compile = False         # update-path compile only; never used here
print(f"[eval] ckpt={CKPT}  config={CFG_PATH}")
print(f"[eval] device={args.device}  mode={args.mode}  episodes={args.episodes} "
      f"max_steps={args.max_steps}  scope={cfg.env.scope}  seed={args.seed}")

# ---- env: ONE in-process world (fresh process; never alongside a train run) ----
task = str(cfg.env.task).split("_", 1)[1]
# action_repeat from the RUN config (v2 runs train at 4): eval must hold each
# action the same number of sim steps or it evaluates a different MDP.
# --max-steps stays in SIM steps; the loop counts agent steps.
REPEAT = int(cfg.env.get("action_repeat", 1) or 1)
if not args.fps:
    args.fps = 30.0 / REPEAT   # real-time playback: one frame per agent step
# EVERY action-semantics param comes from the RUN's own config -- silent-default
# bug #7 (2026-08-11): this call passed only action_repeat, so delta_joint
# policies were evaluated in ABSOLUTE mode (a different MDP: delta outputs read
# as absolute joint targets -> lunge-tips + frozen-posture timeouts). All
# eval_genesis results for delta runs before this line are VOID.
env = GenesisPick(task, size=tuple(cfg.env.size), seed=args.seed, scope=str(cfg.env.scope),
                  action_repeat=REPEAT,
                  action_mode=str(cfg.env.get("action_mode", "absolute")),
                  delta_cap=cfg.env.get("delta_cap", None),
                  delta_leash_mult=cfg.env.get("delta_leash_mult", None),
                  reward_scale=float(cfg.env.get("reward_scale", 1.0)))
print(f"[eval] action_mode={env._action_mode} delta_cap={getattr(env, '_delta_cap', None)}")

# ---- agent: rebuild exactly as train.py does, then load the checkpoint ----
agent = Dreamer(cfg.model, env.observation_space, env.action_space).to(args.device)
ck = torch.load(CKPT, map_location=args.device, weights_only=False)
CKPT_STEP = ck.get("step")  # present in checkpoints saved after 2026-08-10; None before
missing, unexpected = agent.load_state_dict(ck["agent_state_dict"], strict=False)
print(f"[eval] loaded checkpoint (missing {len(missing)}, unexpected {len(unexpected)})")
assert not any(k.startswith(("actor.", "rssm.", "encoder.")) for k in missing), missing
agent.clone_and_freeze()          # act() runs on the _frozen_* clones -- resync post-load
agent.requires_grad_(False)
agent.eval()


def pack(obs, reward):
    """obs dict -> (B=1,) TensorDict, mirroring ParallelEnv.step + lift_dim.

    NO "action" key -- deliberately, and verified 2026-08-08 to match training
    exactly: trainer.begin also calls agent.act on a trans WITHOUT an action key
    (trans["action"] is assigned AFTER act, for replay storage only), the
    encoder consumes only cnn_keys='image' (obs_space has no action entry), and
    the RSSM's previous action is threaded through state["prev_action"], which
    act() returns as the action it just emitted (zeros only at t=0 /
    get_initial_state, and obs_step re-zeroes it wherever is_first is set).
    Runtime proof: test_action_conditioning.py (P1-P4 vs the real
    pick checkpoint: garbage action key in trans -> bit-identical act output).
    """
    d = {k: torch.as_tensor(np.asarray(v)[None]) for k, v in obs.items()}
    d["reward"] = torch.tensor([reward], dtype=torch.float32)
    td = TensorDict(d, batch_size=(1,), device="cpu")
    for k in td.keys():
        if td[k].ndim == 1:
            td[k] = td[k].unsqueeze(-1)
    return td.to(args.device)


def reset_to_uid(uid):
    """Adapter reset, but pinned to an explicit demo uid (reportable ICs)."""
    if env._env is None:
        env._build()                              # gs.init + world build (once)
    # place scope: do NOT pin the uid -- the within-uid resample can loop on a
    # single non-surviving entry (seen: 333@721 x30 -> RuntimeError). Whole-bank
    # sampling matches training's reset distribution anyway.
    if getattr(env._env, 'scope', 'full') == 'place':
        env._env.reset()
    else:
        env._env.reset(options={"uid": int(uid)})  # demo IC: that trial's recorded placement
    # delta_joint mode: the persistent joint target lives in the ADAPTER, and
    # this function bypasses adapter.reset -- re-seed it from measured qpos or
    # it carries over from the previous episode. No-op in absolute mode.
    getattr(env, "sync_delta_target", lambda: None)()
    obs = {"is_first": True, "is_last": False, "is_terminal": False, "image": env._image()}
    for k in STAGE_KEYS + ("task_success",):
        obs[f"log_{k}"] = np.float32(0.0)
    return obs


import cv2  # noqa: E402

print("[eval] building the Genesis world (~20-35 s)...", flush=True)
t0 = time.time()
if env._env is None:
    env._build()
print(f"[eval] world built in {time.time() - t0:.1f} s")
rng = np.random.RandomState(args.seed)
uids = rng.choice(env._env.success_uids, size=args.episodes, replace=True)

# Outcome taxonomy is scope-aware: in scope='place' the can STARTS held, so
# 'picked' is trivially granted on every episode (the pre-2026-08-08 eval
# reported place timeouts as picked 1.00). Place outcomes: placed_v2 (the
# scope's terminal success) / tipped / timeout.
SCOPE = str(cfg.env.scope)
success_key = "placed_v2" if SCOPE == "place" else "picked"
results = []
counts = {success_key: 0, "tipped": 0, "timeout": 0}
ep_tiles = []   # (frames (T,64,128,3) RGB, outcome) per episode, for the grid video
for ep in range(args.episodes):
    t_ep = time.time()
    obs = reset_to_uid(uids[ep])
    state = agent.get_initial_state(1)
    trans = pack(obs, 0.0)
    frames = [obs["image"]]
    done, info, ep_reward, t = False, {}, 0.0, 0
    while not done and t * REPEAT < args.max_steps:
        act, state = agent.act(trans, state, eval=(args.mode == "mode"))
        a = act[0].detach().cpu().numpy().astype(np.float32)
        obs, reward, done, info = env.step(a)
        frames.append(obs["image"])
        trans = pack(obs, float(reward))
        ep_reward += float(reward)
        t += 1
    success = success_key in env._env._granted or bool(info.get(success_key))
    tipped = bool(info.get("tipped"))
    outcome = success_key if success else ("tipped" if tipped else "timeout")
    counts[outcome] += 1
    dt = time.time() - t_ep

    s = args.scale
    vid = OUT / f"ep{ep}_uid{int(uids[ep])}_{outcome}.mp4"
    h, w = 64 * s, 128 * s
    vw = cv2.VideoWriter(str(vid), cv2.VideoWriter_fourcc(*"mp4v"), args.fps, (w, h))
    for f in frames:
        tile = np.hstack([f[..., :3], f[..., 3:]])[:, :, ::-1]   # top|wrist, BGR
        vw.write(cv2.resize(tile, (w, h), interpolation=cv2.INTER_NEAREST))
    vw.release()

    ep_tiles.append((np.stack([np.hstack([f[..., :3], f[..., 3:]])
                               for f in frames]), outcome))
    results.append(dict(ep=ep, uid=int(uids[ep]), outcome=outcome, steps=t,
                        reward=ep_reward, seconds=round(dt, 1), video=str(vid)))
    print(f"ep{ep}: uid={int(uids[ep])} {outcome} ({t} steps, r={ep_reward:.1f}, "
          f"{dt:.1f} s)", flush=True)

# ---- single grid video: every episode as one tile (top|wrist), outcome-labeled.
# Shorter episodes freeze on their last frame; success green / tipped red / timeout gray.
grid_path = None
if ep_tiles:
    T = max(len(fr) for fr, _ in ep_tiles)
    cols = min(4, len(ep_tiles))
    rows = -(-len(ep_tiles) // cols)
    s = args.scale
    th, tw = 64 * s, 128 * s
    OUTCOL = {success_key: (0, 200, 0), "tipped": (0, 0, 220), "timeout": (128, 128, 128)}
    grid_path = OUT / "rollouts_grid.mp4"
    gw = cv2.VideoWriter(str(grid_path), cv2.VideoWriter_fourcc(*"mp4v"),
                         args.fps, (cols * tw, rows * th))
    for t in range(T):
        canvas = np.zeros((rows * th, cols * tw, 3), np.uint8)
        for i, (fr, outcome) in enumerate(ep_tiles):
            tile = fr[min(t, len(fr) - 1)][:, :, ::-1]           # RGB->BGR
            tile = cv2.resize(tile, (tw, th), interpolation=cv2.INTER_NEAREST)
            cv2.putText(tile, outcome[:7], (2, 10), cv2.FONT_HERSHEY_PLAIN,
                        0.8, OUTCOL.get(outcome, (255, 255, 255)), 1, cv2.LINE_AA)
            r0, c0 = (i // cols) * th, (i % cols) * tw
            canvas[r0:r0 + th, c0:c0 + tw] = tile
        gw.write(canvas)
    gw.release()
    print(f"[eval] grid video ({len(ep_tiles)} eps tiled) -> {grid_path}", flush=True)

n = max(len(results), 1)
summary = dict(
    checkpoint=str(CKPT), episodes=len(results), mode=args.mode, seed=args.seed,
    max_steps=args.max_steps, ic_mode="demo", scope=SCOPE,
    **{success_key: counts[success_key] / n},
    tipped=counts["tipped"] / n,
    timeout=counts["timeout"] / n,
    mean_steps=float(np.mean([r["steps"] for r in results])),
    mean_reward=float(np.mean([r["reward"] for r in results])),
    per_episode=results,
)
(OUT / "metrics.json").write_text(json.dumps(summary, indent=1))
if args.append_metrics:
    _line = {"step": int(CKPT_STEP) if CKPT_STEP is not None else -1,
             f"eval/{success_key}": summary[success_key],
             "eval/tipped": summary["tipped"], "eval/timeout": summary["timeout"],
             "eval/mean_steps": summary["mean_steps"],
             "eval/mode_flag": 1.0 if args.mode == "mode" else 0.0}
    with open(pathlib.Path(args.append_metrics) / "metrics.jsonl", "a") as _f:
        _f.write(json.dumps(_line) + "\n")   # O_APPEND: atomic for small lines
    print(f"[eval] appended eval/* line (step {_line['step']}) to {args.append_metrics}/metrics.jsonl")
print(f"\n[eval] {n} episodes ({args.mode}, demo ICs): "
      f"{success_key} {summary[success_key]:.2f}  tipped {summary['tipped']:.2f}  "
      f"timeout {summary['timeout']:.2f}  mean_steps {summary['mean_steps']:.0f}")
print(f"[eval] wrote {OUT}/metrics.json + {len(results)} mp4s")

# ---- wandb (opt-in; NEVER fatal to the eval -- metrics.json is already on disk) ----
if args.wandb:
    try:
        import wandb  # noqa: E402

        run_name = f"{RUN_DIR.name}-eval"
        if CKPT_STEP is not None:
            run_name += f"-step{int(CKPT_STEP)}"
        wb = wandb.init(
            entity="jambotime", project="r2dreamer_genesis", name=run_name,
            job_type="eval", tags=["eval", SCOPE],
            config=dict(checkpoint=str(CKPT), ckpt_step=CKPT_STEP, mode=args.mode,
                        seed=args.seed, episodes=len(results), max_steps=args.max_steps,
                        ic_mode="demo", scope=SCOPE, train_run=RUN_DIR.name),
        )
        scalars = {
            f"eval/{success_key}": summary[success_key],
            "eval/tipped": summary["tipped"],
            "eval/timeout": summary["timeout"],
            "eval/mean_steps": summary["mean_steps"],
            "eval/mean_reward": summary["mean_reward"],
            "eval/episodes": len(results),
        }
        wb.log(scalars)
        if grid_path is not None:
            try:
                wb.log({"video/rollouts_grid": wandb.Video(
                    str(grid_path), format="mp4",
                    caption=f"{len(results)} eps (top|wrist per tile): "
                            + " ".join(f"ep{r['ep']}={r['outcome']}" for r in results))})
            except Exception as e:  # a bad mp4 must not sink the rest
                print(f"[eval] wandb grid video upload failed: {e}")
        wb.summary.update(scalars)
        wb.finish()
        print(f"[eval] wandb run logged: {wb.url}")
    except Exception as e:
        print(f"[eval] wandb logging FAILED (eval results unaffected): {e}")
