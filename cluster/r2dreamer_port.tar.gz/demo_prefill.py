"""Demo prefill: load npz demonstration episodes into the replay buffer (plan section 3).

Gated on ``config.env.demo_dir`` (null / absent => no-op, zero behavior change).

Buffer contract honored here (see GENESIS_PORT_PLAN.md section 3):
  - LazyTensorStorage(ndim=2) lays data out as (time, columns) and FIXES the
    column count at the FIRST extend; online collection later extends with
    exactly ``env_num`` columns, so demos are packed into exactly ``env_num``
    equal-length streams (greedy longest-first balancing, then equalized by
    looping whole demos and truncating the final duplicate -- every original
    episode stays intact, only padding copies get cut).
  - Row keys/dtypes/shapes mirror what trainer.begin stores online:
    image u8 (64,64,6); reward f32 (1,); is_first/is_last/is_terminal bool (1,);
    action f32 (7,) (npz already uses the backward-looking convention: zero
    action on the is_first frame -- loads as-is); log_* f32 (1,) zeros except
    log_picked on reward-bearing frames (pick-scope demos: reward 1.0 == picked;
    log_task_success stays 0 -- nested only, per the adapter); stoch/deter
    zeros from agent.rssm.initial shapes (slice-context only; self-heal via
    replay_buffer.update after every sample); episode int32 = column index,
    matching the trainer's constant per-slot ids.
  - ``discount`` and ``logprob`` npz keys are dropped.

Step accounting: trainer.begin starts at step = buffer.count() * action_repeat,
so the prefill count is spent from the env.steps budget -- set env.steps =
prefill + desired online steps. Demos are FIFO-evictable: with buffer.max_size
M total transitions and P prefill transitions, the first demo frame is evicted
after M - P online env steps and the last by M online env steps.

Re-injection (``env.demo_reinject_every``, default 0 = off): when > 0, the FULL
demo set is re-added to the buffer every N ONLINE env steps via the same
add_chunk path as prefill (fabricated zero latents self-heal via
replay_buffer.update after every sample). Step accounting is safe by
construction: trainer.begin derives ``step`` from buffer.count() exactly ONCE
(before the loop) and afterwards increments it purely from env-side dones, so
mid-run add_chunk extends grow the buffer without inflating the step counter
(only the initial prefill is deliberately counted against env.steps). Known
mild artifact: slices straddling a re-injection block's END mix demo context
into a resumed online episode (no is_first there); one boundary per column per
re-injection, same class of staleness the self-healing latents already absorb.

Demo oversampling (``env.demo_duplicate``, default 1): the loaded demo set is
duplicated N times before packing, both at prefill and at every re-injection
(shared add_demo_set path). Bounded: duplicate*frames must stay < 0.5 *
buffer.max_size. Note the duplicated prefill spends N times the step budget.
"""
import pathlib

import numpy as np
import torch
from tensordict import TensorDict

LOG_KEYS = ("log_picked", "log_placed", "log_contact", "log_nested", "log_tipped", "log_task_success")
# scope='place' adds log_placed_v2 to the adapter's obs keys; prefill rows must
# carry the SAME columns (LazyTensorStorage fixes the column set at first extend).
PLACE_LOG_KEYS = LOG_KEYS + ("log_placed_v2",)
CHUNK_ROWS = 512  # time-rows per extend; keeps peak TensorDict copies small


def _load_episode(path, downsample=1, reward_scale=1.0):
    with np.load(path) as d:
        ep = {
            "image": d["image"],
            "action": d["action"].astype(np.float32),
            # reward_scale (env.reward_scale): the SAME factor the genesis
            # adapter applies to env-side rewards -- demo and online rows must
            # encode the same reward function (npz terminal 1.0 -> scale).
            "reward": d["reward"].astype(np.float32) * np.float32(reward_scale),
            "is_first": d["is_first"].astype(bool),
            "is_last": d["is_last"].astype(bool),
            "is_terminal": d["is_terminal"].astype(bool),
        }
    T = len(ep["reward"])
    assert ep["image"].shape == (T, 64, 64, 6) and ep["image"].dtype == np.uint8, path
    assert ep["action"].shape == (T, 7), path
    assert ep["is_first"][0] and ep["is_last"][-1], path
    assert not ep["action"][0].any(), f"{path}: expected zero action on the is_first frame"
    # ACTION-CONVENTION FIX (2026-08-04): the npz stores actions BACKWARD-in-row
    # (row t = action that PRODUCED obs_t; zero on is_first), but trainer.begin
    # stores online rows FORWARD-in-row (row t = action chosen AT obs_t; zero on
    # the done row) and Buffer.sample() shifts stored actions back one step to
    # build the (obs_t, action-that-produced-obs_t) pairs RSSM.observe expects.
    # Loading the npz as-is (all runs before this date) therefore fed demo
    # prev-actions ONE STEP STALE into the world model. Shift up by one so demo
    # rows are convention-identical to online rows; the final row gets a zero
    # placeholder exactly like online done rows. This alignment is also what the
    # actor-BC loss (dreamer.py) relies on to pair posterior states with the
    # demo action executed at that state.
    # DOWNSAMPLE (env.demo_downsample, must equal env.action_repeat): demos are
    # 30 Hz tapes with one env step per row; with adapter-side action_repeat N
    # an ONLINE row covers N sim steps, so demo rows must too, or the buffer
    # mixes two contradictory dynamics. New row j keeps raw frame idx[j]
    # (0, N, 2N, ..., always including the terminal frame); its reward is the
    # SUM over the covered window (sparse terminal +1 preserved exactly) and
    # its backward-convention action is the MEAN of the window's raw actions
    # (approximates the held action; teleop commands are smooth at 30 Hz).
    # Applied BEFORE the forward-shift below, which then operates on the
    # downsampled rows exactly as it does on raw ones.
    if downsample > 1:
        T = len(ep["reward"])
        idx = np.arange(0, T, downsample)
        if idx[-1] != T - 1:
            idx = np.append(idx, T - 1)
        prev = np.concatenate([[-1], idx[:-1]])
        csum = np.concatenate([[0.0], np.cumsum(ep["reward"], dtype=np.float64)])
        reward = (csum[idx + 1] - csum[prev + 1]).astype(np.float32)
        acsum = np.concatenate(
            [np.zeros((1, ep["action"].shape[1])), np.cumsum(ep["action"], axis=0, dtype=np.float64)]
        )
        action = ((acsum[idx + 1] - acsum[prev + 1]) / (idx - prev)[:, None]).astype(np.float32)
        action[0] = 0.0  # is_first row keeps the zero-action convention
        ep = {
            "image": ep["image"][idx],
            "action": action,
            "reward": reward,
            "is_first": ep["is_first"][idx],
            "is_last": ep["is_last"][idx],
            "is_terminal": ep["is_terminal"][idx],
        }
    ep["action"] = np.concatenate([ep["action"][1:], np.zeros_like(ep["action"][:1])])
    return ep


def _pack_streams(eps, env_num):
    """Greedy longest-first balancing into env_num streams, then equalize by
    looping whole demos; the last padding copy is truncated to the exact target.
    Returns (streams, target): streams = list of (episode_idx, length) lists."""
    order = sorted(range(len(eps)), key=lambda i: -len(eps[i]["reward"]))
    streams = [[] for _ in range(env_num)]
    lengths = [0] * env_num
    for i in order:
        j = min(range(env_num), key=lambda k: lengths[k])
        streams[j].append((i, len(eps[i]["reward"])))
        lengths[j] += len(eps[i]["reward"])
    target = max(lengths)
    for j in range(env_num):
        k = 0
        while lengths[j] < target:
            i, T = streams[j][k % len(streams[j])]  # cycle this stream's own demos
            take = min(T, target - lengths[j])
            streams[j].append((i, take))
            lengths[j] += take
            k += 1
    assert all(length == target for length in lengths)
    return streams, target


def add_demo_set(replay_buffer, agent, config):
    """Load all demos from env.demo_dir and extend the buffer (chunked add_chunk).

    Shared by the initial prefill and periodic re-injection; reloads the npz
    files from disk on every call (re-injection is infrequent -- avoids pinning
    the multi-GB packed arrays in RAM for the whole run). Returns the info dict,
    or None when env.demo_dir is unset."""
    demo_dir = config.env.get("demo_dir", None)
    if not demo_dir:
        return None
    ds = int(config.env.get("demo_downsample", 1) or 1)
    repeat = int(config.env.get("action_repeat", 1) or 1)
    assert ds == repeat, (
        f"env.demo_downsample ({ds}) must equal env.action_repeat ({repeat}): "
        "demo rows and online rows must cover the same number of sim steps, or "
        "the world model learns contradictory dynamics from the same buffer"
    )
    count_before = replay_buffer.count()
    env_num = int(config.env.env_num)
    files = sorted(pathlib.Path(demo_dir).expanduser().glob("*.npz"))
    assert files, f"env.demo_dir is set but contains no .npz files: {demo_dir}"

    scale = float(config.env.get("reward_scale", 1.0) or 1.0)
    eps = [_load_episode(f, downsample=ds, reward_scale=scale) for f in files]
    max_size = int(float(config.buffer.max_size))
    # Demo oversampling (env.demo_duplicate, default 1): duplicate the demo set
    # N times, at prefill AND at every re-injection (this function serves both).
    # Bounded so demos never dominate the buffer: duplicate*frames < 0.5*max_size.
    dup = int(config.env.get("demo_duplicate", 1) or 1)
    assert dup >= 1, dup
    raw_frames = sum(len(e["reward"]) for e in eps)
    assert dup * raw_frames < 0.5 * max_size, (
        f"demo_duplicate={dup} x {raw_frames} demo frames = {dup * raw_frames} "
        f">= 0.5 * buffer.max_size ({max_size}); lower demo_duplicate or raise max_size"
    )
    eps = eps * dup  # shallow copies: _pack_streams/stream_cat only read the arrays
    n_frames = sum(len(e["reward"]) for e in eps)
    n_rewarded = sum(bool(e["reward"][-1] > 0 and e["is_terminal"][-1]) for e in eps)

    streams, target = _pack_streams(eps, env_num)
    total = env_num * target
    assert total <= max_size, (
        f"prefill ({total} transitions) exceeds buffer.max_size ({max_size}); raise max_size"
    )

    # Latent shapes from the agent (values are refreshed by replay_buffer.update
    # after every sample, so zeros are the same staleness as old online data).
    stoch0, deter0 = agent.rssm.initial(1)
    s_shape, d_shape = tuple(stoch0.shape[1:]), tuple(deter0.shape[1:])

    # Materialize per-stream arrays (B, target, ...). ~2.4 GB transient at 94k frames.
    def stream_cat(key):
        return np.stack(
            [np.concatenate([eps[i][key][:take] for i, take in streams[j]]) for j in range(env_num)]
        )

    image = stream_cat("image")
    action = stream_cat("action")
    reward = stream_cat("reward")[..., None]
    is_first = stream_cat("is_first")[..., None]
    is_last = stream_cat("is_last")[..., None]
    is_terminal = stream_cat("is_terminal")[..., None]

    for t0 in range(0, target, CHUNK_ROWS):
        t1 = min(t0 + CHUNK_ROWS, target)
        c = t1 - t0
        row = {
            "image": torch.from_numpy(image[:, t0:t1]),
            "action": torch.from_numpy(action[:, t0:t1]),
            "reward": torch.from_numpy(reward[:, t0:t1]),
            "is_first": torch.from_numpy(is_first[:, t0:t1]),
            "is_last": torch.from_numpy(is_last[:, t0:t1]),
            "is_terminal": torch.from_numpy(is_terminal[:, t0:t1]),
            "stoch": torch.zeros((env_num, c) + s_shape, dtype=torch.float32),
            "deter": torch.zeros((env_num, c) + d_shape, dtype=torch.float32),
            "episode": torch.arange(env_num, dtype=torch.int32).unsqueeze(1).expand(env_num, c).contiguous(),
            # Demo flag for the actor-BC auxiliary loss (dreamer.py): prefill /
            # re-injection rows are True, online rows False (trainer.begin adds
            # the same column so the storage key-set stays consistent).
            "is_demo": torch.ones((env_num, c, 1), dtype=torch.bool),
        }
        scope = config.env.get("scope", "pick")
        for k in (PLACE_LOG_KEYS if scope == "place" else LOG_KEYS):
            row[k] = torch.zeros((env_num, c, 1), dtype=torch.float32)
        if scope == "place":
            # place-scope demos: the reward-bearing (terminal) frame is placed_v2,
            # which is also the scope's task_success.
            row["log_placed_v2"] = (row["reward"] > 0).to(torch.float32)
            row["log_task_success"] = row["log_placed_v2"].clone()
        else:
            # pick-scope demos: the reward-bearing (terminal) frame is the pick.
            row["log_picked"] = (row["reward"] > 0).to(torch.float32)
        replay_buffer.add_chunk(TensorDict(row, batch_size=(env_num, c)))

    # FIFO ring: once full, count saturates at max_size instead of growing.
    expected = min(count_before + total, max_size)
    assert replay_buffer.count() == expected, (replay_buffer.count(), expected)
    return {
        "episodes": len(eps),
        "episodes_unique": len(files),
        "demo_duplicate": dup,
        "reward_scale": scale,
        "terminal_reward_values": sorted(
            {float(e["reward"][-1]) for e in eps if e["reward"][-1] > 0}
        ),
        "frames_raw": n_frames,
        "rewarded_terminals": n_rewarded,
        "transitions_added": total,
        "rows_per_stream": target,
        "padding_frames": total - n_frames,
        "eviction_note": (
            f"FIFO: first demo frame evicted after {max_size - total} online env steps, "
            f"all demo frames gone by {max_size} online env steps (buffer.max_size={max_size})"
        ),
    }


def prefill_from_npz(replay_buffer, agent, config):
    """Initial demo prefill (gated on env.demo_dir; null => no-op)."""
    return add_demo_set(replay_buffer, agent, config)


def make_reinjector(replay_buffer, agent, config):
    """Zero-arg callable that re-adds the full demo set, or None when off.

    Off unless BOTH env.demo_dir and env.demo_reinject_every > 0 are set. The
    trainer calls it every env.demo_reinject_every ONLINE env steps. Uses the
    same add_chunk path as prefill; does NOT touch the trainer's step counter
    (see module docstring, "Re-injection")."""
    every = int(config.env.get("demo_reinject_every", 0) or 0)
    if every <= 0 or not config.env.get("demo_dir", None):
        return None

    def reinject():
        return add_demo_set(replay_buffer, agent, config)

    return reinject
