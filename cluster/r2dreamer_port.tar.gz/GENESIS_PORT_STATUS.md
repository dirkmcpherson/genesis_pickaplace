# Genesis port status (stage 2: demo prefill + first overnight run; place scope built)

Working doc for the GENESIS_PORT_PLAN.md build. Updated as verification rungs run.
Sessions: 2026-08-01 (stage 1), 2026-08-01 later (stage 2), 2026-08-01 night (eval script),
2026-08-02 (PLACE scope).

## Files (stage 1)

- `envs/genesis.py` — new `GenesisPick` adapter (gymnasium.Env; lazy `_build()` in the
  spawn worker; `FullTaskEnv(backend='cpu', max_steps=1e9, scope, camera_rig=True)`;
  64x64x6 image; log_* stage flags emitted ONLY on the episode-final step, from
  `_granted` + info; `log_task_success` = nested only; NO `reward` in obs; plain Box
  action space with NO `.discrete` attr — hasattr check in Dreamer would misroute).
- `envs/__init__.py` — `genesis` branch in `make_env` (passes `config.scope`,
  `config.seed + id`), falls through to shared TimeLimit + Dtype wrappers.
- `configs/env/genesis_pick.yaml` — per plan §4: env_num 4, eval_episode_num 0,
  action_repeat 1, time_limit 1200, scope pick, storage_device cpu, horizon 1000.
- `configs/configs.yaml` — `buffer.storage_device: ${oc.select:env.storage_device,${device}}`
  (env configs may pin replay to cpu; others unchanged). Needed because `- _self_` is
  last in the defaults list, so a group file cannot override `buffer.*` directly.
- `configs/model/_base_.yaml` — `horizon: ${oc.select:env.horizon,333}` (same trick;
  cross-package model→env interpolation is already the house pattern, cf. encoder keys).
- `tools.py` `Logger.write` — plan §2 risk: 6-channel video crashes TensorBoard
  `add_video` (C must be 1/3). Fix: C==6 → hsplit into top‖wrist side-by-side.
- `trainer.py` `begin` done-block — plan §5: train path had no log_* aggregation;
  now logs `episode/train_<name>` from the finished slot's final trans.

## Known design points / caveats

- ONE Genesis world per process → `env_num` spawn workers, one world each. Worlds
  build lazily on first `reset()` inside the worker (constructor is cloudpickled).
- TimeLimit truncation happens OUTSIDE the adapter, so truncated episodes report
  all-zero log_*. Exact for picked/tipped in scope='pick' (either terminates);
  only pre-pick goal contact can be under-reported.
- video_pred_log stays False (no decoder for rep_loss=r2dreamer).
- Do not run two Genesis builds in one process (rung (a) standalone must be a
  separate process from any train run).

## Environment fixes (venv .venv, py3.11 / torch 2.8 / numpy 2.4.6 / genesis 0.2.1)

- numpy 2.4.6 (genesis install upgraded past the 1.26 pin) removed `np.reshape`'s
  `newshape` kwarg -> torch 2.8's tensorboard `_prepare_video` TypeErrors on every
  add_video. Fixed in `tools.py`: drop-in `_prepare_video_np2` monkeypatched over
  `torch.utils.tensorboard.summary._prepare_video`. Did NOT downgrade numpy (would
  gamble the working genesis stack against a one-line library bug).
- moviepy 2.2.1 has no `moviepy.editor` -> torch's make_video silently emitted
  0-byte GIFs. Downgraded to moviepy==1.0.3 in .venv (genesis-world declares
  moviepy>=2.0.0 but does not exercise it in our headless camera_rig path — rung (a)
  re-passed identically after the downgrade; pip prints a resolver warning, expected).
- `train/action_min/max` ~±4: bounded_normal rsample is unclamped by design
  (imagination-path stat); env boundary is safe — `pick_env.denormalize_action`
  clips to [-1,1] before scaling. No change needed.

## Verification ladder (2026-08-01, all with MUJOCO_GL=egl GENESIS_PICKAPLACE_ROOT=.../genesis_pickaplace)

- (a) PASS — full make_env wrapper stack standalone: spaces (image (64,64,6) uint8,
  6x log_* keys, plain Box(-1,1,(7,)) with no .discrete), reset obs contract
  (is_first, no reward key, log_* all zero), 20 random steps with key-set stability,
  log_* zero on non-final steps. World build ~18-34 s, ~30 ms/step.
- (b) PASS — `train.py env=genesis_pick env.env_num=2 env.steps=500
  trainer.eval_every=1e9 logdir=runs/genesis_smoke`: spawn-worker Genesis builds,
  `Encoder CNN shapes: {'image': (64, 64, 6)}`, resolved config storage_device=cpu /
  model.horizon=1000 / time_limit=1200, 150 agent.updates ran (losses moving,
  train/loss/dyn 9.2->3.5), episodes terminate via tip rule with
  `episode/train_picked/..._tipped` scalars, `train_video` in tensorboard as a
  128x64 GIF (top‖wrist stitch working), latest.pt saved. Evidence: runs/genesis_smoke/.

## Stage 2: demo prefill (BUILT, verified 2026-08-01)

Files:
- `demo_prefill.py` — `prefill_from_npz(replay_buffer, agent, config)`, gated on
  `env.demo_dir` (null => no-op, zero behavior change). Loads all `*.npz`
  (drops discount/logprob), packs demos into EXACTLY env_num equal-length
  streams (greedy longest-first balance; equalized by looping whole demos and
  truncating only the final padding copy — every original episode stays whole),
  fabricates stoch (32,16)/deter (2048,) zeros from `agent.rssm.initial` (they
  self-heal via `replay_buffer.update` after every sample), episode = column
  index int32 (matches trainer's constant slot ids), log_* zeros except
  log_picked on reward-bearing frames. Feeds (B, 512-row) chunks.
- `buffer.py` — new `Buffer.add_chunk(data)`: extend with a (B, T) TensorDict
  (same layout as T `add_transition` calls; probe-verified storage is (time,
  columns), max_size counted in TOTAL transitions, FIFO evicts oldest rows,
  wrong column count raises).
- `train.py` — prefill call between agent creation and trainer; prints prefill
  info + step accounting; asserts env.steps > prefill (prefill spends the step
  budget: trainer starts at `buffer.count()`).
- `dreamer.py` `update` — new `train/data/reward_frames` + `train/data/reward_sum`
  metrics: reward-bearing frames actually sampled per batch (demo-mixing /
  eviction visibility on tensorboard).
- `configs/env/genesis_pick.yaml` — `demo_dir: null` key.

Demo set: `~/workspace/dreamerv3-torch/demonstrations/genesis_pick` — 91
episodes, 94,454 frames, 79 rewarded terminals (audited: shapes/dtypes/zero
action on is_first all assert-clean; lengths 172-5363).

Verification (all PASS):
- (a) prefill alone (script): 91 episodes / 94,454 raw frames / 79 rewarded
  terminals loaded; env_num=2 -> 94,610 transitions (156 padding), env_num=8 ->
  95,328 (874 padding); storage readback exact vs independently packed
  reference (random rows x all keys, per-column rewarded-frame counts, chunked
  extend orientation); 50 sampled batches: 35-49 rewarded frames, 40-55
  is_first frames (expected ~0.85/batch: 79/94k x 1024); post-prefill
  `add_transition` with a trainer-shaped (B,) row extends cleanly.
- (b) 2000-step training run (env_num=2, pretrain=100, update_log_every=50):
  demo frames SAMPLED in training batches — 26/41 logged update snapshots had
  nonzero `data/reward_frames` (39 rewarded demo frames total); losses stepping
  (loss/rew 5.45 -> 0.02, i.e. reward head fits the demo terminals; dyn moving);
  1100 updates, 8 online episodes, latest.pt saved, exit 0. ~18 env-steps/s at
  env_num=2 with 1 update per 2 steps (update ~75 ms compiled fp16).

## Overnight run (launched 2026-08-01, detached setsid, survives session)

    cd ~/workspace/r2dreamer && MUJOCO_GL=egl \
      GENESIS_PICKAPLACE_ROOT=/home/j/workspace/genesis_pickaplace \
      nohup setsid ./.venv/bin/python train.py env=genesis_pick \
      env.demo_dir=/home/j/workspace/dreamerv3-torch/demonstrations/genesis_pick \
      env.env_num=8 env.steps=3.1e6 env.train_ratio=128 buffer.max_size=7e5 \
      trainer.pretrain=1000 seed=0 logdir=runs/genesis_pick_demo_s0 \
      > runs/genesis_pick_demo_s0/run.log 2>&1 &

Budget rationale (documented choice):
- steps 3.1e6 = 95,328 prefill + ~3.0M online (plan suggested 3-5M; the
  1000-update demo pretrain burst front-loads the demo signal).
- train_ratio 128 (config's own tune-down suggestion): 1 update / 8 env steps.
  Measured in-run: 64.2 env-steps/s steady-state ~= 231k steps/h -> 3M online
  in ~13 h. At the default 512 the GPU
  (3080 Ti) would cap the run at ~8 steps/s (>100 h). ~375k total updates
  (vs dv3's ~104k for its 5M-step arm — higher update density).
- buffer.max_size 7e5 total transitions (RAM-bound: ~35 KB/transition -> 24.5 GB
  storage + 8 x 1.6 GB Genesis workers + ~4 GB trainer ~= 41 GB of 62 GB).
  Eviction (FIFO, cannot be ring-fenced in torchrl storage): first demo frame
  evicted after 7e5 - 95,328 = 604,672 online steps; ALL demo frames gone by
  700k online steps (~20% into the run). Sizing demos to survive all 3M steps
  would need ~108 GB — impossible here; watch `train/data/reward_frames` drop
  toward the online-only level after ~600k steps.

Launch health (2026-08-01 19:18, ~4 min in): prefill printed 95,328 transitions
/ 79 rewarded terminals; 8 worlds built; 1000-update pretrain ran (loss/rew
0.016 after burst); online training at step 100k+, 64.2 fps, demo reward frames
still appearing in batches (train/data/reward_frames=1.0 at step 100,332);
episodes terminating normally (tip rule, lengths ~85-160). PID: `pgrep -f
genesis_pick_demo_s0`; monitor via runs/genesis_pick_demo_s0/{run.log,metrics.jsonl}.

## Standalone policy eval: `eval_genesis.py` (built + verified 2026-08-01)

dv3 genesis_eval.py equivalent. Fresh process (one gs.init/world per process --
never run alongside a train run's world in-process; separate PROCESS is fine),
single CPU Genesis world via the `envs/genesis.py` adapter, N episodes from
DEMO ICs (per-episode uid drawn from `FullTaskEnv.success_uids`, reset via
`options={'uid': ...}` -- same reset distribution training uses, and the uid is
logged per episode). Rebuilds the Dreamer from the run's own
`.hydra/config.yaml` (device interpolations re-pointed via `cfg.device`),
loads `latest.pt['agent_state_dict']` (strict=False + assert no actor/rssm/
encoder keys missing), then `clone_and_freeze()` -- `Dreamer.act` runs on the
`_frozen_*` clones, so a resync after load is mandatory. Action selection
mirrors `act(eval=...)`: `--mode sample` (rsample; DEFAULT, matches the dv3
protocol "eval SAMPLES") or `--mode mode` (deterministic). Obs are packed
exactly like `ParallelEnv.step` + `lift_dim` ((1,) batch, scalars lifted to
(1,1)). Outcomes read from `FullTaskEnv._granted` + final-step info (picked /
tipped / timeout -- scope='pick' terminates on either of the first two).
Writes `<run>/policy_eval/metrics.json` + per-episode top|wrist mp4s
(`ep{n}_uid{uid}_{outcome}.mp4`, 4x nearest upscale, 20 fps).

    MUJOCO_GL=egl GENESIS_PICKAPLACE_ROOT=~/workspace/genesis_pickaplace \
      ./.venv/bin/python eval_genesis.py --checkpoint runs/<run>/latest.pt \
      --episodes 8 --max-steps 1200 [--mode sample] [--device cpu] [--seed 0]

Defaults: device=cpu (training owns the GPU), torch threads capped at 4.

Verified (2026-08-01, while the s0 training ran undisturbed at ~345k steps):
- `runs/genesis_pick_demo_s0/latest.pt` does NOT exist yet -- train.py writes
  latest.pt ONLY at the end of the run (`torch.save` after `trainer.begin`;
  the trainer has NO periodic checkpoint). The script errors cleanly on it.
  **Gap for stage 3: add a periodic latest.pt save to trainer.begin (future
  runs), else the overnight run is only evaluable after it finishes (~13 h).**
- Real run on `runs/genesis_prefill_smoke/latest.pt` (the 2000-step smoke),
  `--episodes 3 --max-steps 1200`: checkpoint loaded missing 0/unexpected 0,
  world built 20.6 s, episodes uid305 tipped (4 steps, 1.5 s) / uid309 tipped
  (180 steps, 10.4 s) / uid320 tipped (203 steps, 11.6 s) -> picked 0.00,
  tipped 1.00, total wall 49 s. Expected-bad number for a smoke checkpoint;
  the deliverable is the working measurement. Videos play (204 frames,
  512x256). Evidence: `runs/genesis_prefill_smoke/policy_eval/`.

## PLACE scope (built + verified 2026-08-02; genesis_pickaplace commit 70b1d85)

Task `genesis_place` = place specialist from banked post-pick entry states
(PAPER_PLAN stage-wise matrix). Env side lives in genesis_pickaplace
`baselines/rl/full_env.py` scope='place':

- reset restores a random `baselines/pick_entry_states.json` entry (66 post-pick
  states: arm qpos, grip cmd/obs, held can pose, goal), fingers at the MEASURED
  closure, 20 settle steps holding the entry commands, held-can check
  (can_z > 0.13) with resample. **Survival 11/13 = 0.85** (deterministic: uids
  234, 251 drop the can; everything else restores). `options={'uid': ...}` pins
  an entry (fails loudly instead of swapping).
- PLACED_V2 terminal +1: grip cmd < 0.45 + can in shelf footprint/z-band +
  tilt < 20 deg, 10 consecutive frames. Tip rule kept; nested proxy does NOT
  terminate place episodes (it cut uid 242's replay rewardless 9 frames short of
  placed_v2 -- fixed, then 3/3). Default cap 600.
- Open-loop replay check (verify_place_scope.py, r2dreamer venv): 233/242/262
  post-entry demo actions all reach placed_v2 at EXACTLY the offline-scan frame
  offsets (397/283/174) -- entries are actionable, and restore+replay is
  deterministic.

r2dreamer side:
- `configs/env/genesis_place.yaml` -- clone of genesis_pick: scope place,
  time_limit 600, task genesis_place (adapter already passed config.scope).
- `envs/genesis.py` -- scope-GATED extra obs key `log_placed_v2` +
  `log_task_success` = placed_v2 when scope='place' (pick key set byte-identical
  to before; the running s0 pick training is untouched -- separate process,
  code loaded before the edit).
- `demo_prefill.py` -- place-scope rows carry the log_placed_v2 column (buffer
  fixes columns at first extend) and mark it + task_success on rewarded frames.
- Demos: `baselines/rl/to_dreamer_demos_place.py` slices episodes_all_images
  success episodes from the bank entry frame to placed_v2+1 (env-identical
  predicate), dreamer npz WITH images, reward 1.0 on terminal. **41 demos /
  20,762 frames / 41 rewarded terminals** (len 149/435/1689 min/med/max) ->
  `genesis_pickaplace/baselines/demonstrations/genesis_place` (rsync only).
  25/66 entries skipped: their recorded frames never satisfy the release-based
  predicate (mostly old z-band-proxy 'placed' demos; ALL 20 nested-stage demos
  qualify). Verified against demo_prefill._load_episode asserts (41/41 clean).
- Adapter smoke (scope='place', CPU world): reset/step key-set stability incl.
  log_placed_v2, 30 zero-action steps clean.

Before a place training run can launch: nothing structural. Suggested launch =
the s0 recipe with `env=genesis_place env.demo_dir=.../demonstrations/genesis_place`
(prefill 20,762 spends that much of env.steps; smaller than pick's 95k so demos
fit comfortably in buffer.max_size 7e5). NOT yet done: a 500-step train.py smoke
on env=genesis_place (GPU is owned by the s0 pick run) -- run it before the
overnight; eval_genesis.py works for place unchanged (outcomes read _granted,
which now carries placed_v2).

## Demo re-injection (built + verified 2026-08-02; applies to NEXT runs)

`env.demo_reinject_every` (default 0 = off, added to both genesis env yamls):
when > 0, the FULL demo set is re-added to the buffer every N ONLINE env steps
via the prefill's add_chunk path (demo_prefill.make_reinjector -> train.py ->
OnlineTrainer(demo_reinjector=, demo_reinject_every=)). Step-safe by
construction: trainer.begin reads buffer.count() ONCE to seed `step`, then
increments from env dones only -- re-injections grow the buffer without
spending the env.steps budget (only prefill is counted). Logs
`train/data/demo_reinjections` + a console line per injection. Verified on a
tiny CPU run (genesis_place, env_num=2, steps=prefill+500, every=200,
separate process from the live s0 place run): 2 injections at exactly
start+200/start+400, each block carries the prefill's 41 rewarded demo
terminals, loop ran its full online budget (test: scratchpad test_reinject.py,
ALL ASSERTIONS PASSED). Known mild artifact: slices straddling a re-injection
block's END mix demo context into the resumed online episode (one boundary
per column per injection). Note found en route (pre-existing, NOT re-injection):
buffer rows > env steps -- the trainer stores a row for done frames too
(~10% overhead at place's short tipped episodes).

## Run-3 place levers (built + verified 2026-08-02 late; vs run 2's hold-forever)

Run 2 (runs/genesis_place_v2_s0) equilibrium: many 600-step timeouts, zero
placed_v2 ever experienced online; 41 demo terminals dilute to ~41-in-700k.
Three levers, all default-off (existing configs/runs byte-identical):

- `full_env.py` scope='place' TRAINING-ONLY shaping (`FullTaskEnv(shaping=True)`,
  default False): potential-based `r += GAMMA*phi(s') - phi(s)`,
  `phi = -2.0 * xy-dist(can, shelf-footprint center (0.75,-0.1875))` (same
  rectangle the placed_v2 check uses), plus per-step cost -0.005. **GAMMA =
  0.999 (the agent's discount, horizon 1000), deliberately NOT the spec'd
  0.99**: at 0.99 the stationary leak +(1-g)*2d = +0.02d beats the step cost at
  65/66 banked entries (median d 0.34 -> +0.0018/step -> +1.1 per 600-step
  timeout > the +1 terminal — would RE-create hold-forever; measured, see unit
  test). At 0.999 leak <= 0.001 < cost everywhere, and matched-gamma shaping is
  policy-invariant. Honest metric UNCHANGED: sparse placed_v2 / log_task_success;
  eval builds envs without shaping.
- `env.place_shaping` (bool, default false) threaded make_env -> GenesisPick ->
  FullTaskEnv(shaping=).
- `env.demo_duplicate` (int, default 1): demo_prefill.add_demo_set duplicates
  the loaded demo set N times at prefill AND at every re-injection (shared
  path); bounded `dup*frames < 0.5*buffer.max_size`. Stats now carry
  demo_duplicate/episodes_unique. NOTE: the duplicated prefill spends N times
  the step budget.
- `configs/env/genesis_place_shaped.yaml` = genesis_place + place_shaping true
  + demo_reinject_every 200000 + demo_duplicate 5 (5 x 20,762 ~= 104k frames,
  fits the 0.5*7e5 bound; prefill spends ~104k of env.steps).

Verified (scratchpad test_place_shaping_unit.py + test_shaped_smoke.py, CPU,
separate processes from the live run): scripted can teleport toward shelf
r ~= +0.15/step, away ~= -0.23/step, all matching closed form <1e-3; stationary
-0.004/step (net-negative, as designed); shaping=False step pays exactly 0.0.
Smoke (env_num=2, steps=prefill+300 on genesis_place_shaped): prefill stats
count 41x5=205 episodes / 205 rewarded terminals, and post-prefill online rows
carry nonzero shaped rewards of both signs.

## Actor-BC auxiliary loss (built + verified 2026-08-04; vs hold-forever)

Motivation: place-scope training converges to hold-forever across 8 reward
variants -- 41 demo episodes SHOW the release but imagination never commits to
it. New: actor imitates demo actions at demo posterior states, RL refines.

- Demo flag: buffer rows carry a new bool column `is_demo` -- True on all
  prefill/re-injection rows (demo_prefill add_demo_set), False on online rows
  (trainer.begin adds the column to every stored trans, so the storage key-set
  is identical whichever path extends first).
- BC loss (dreamer.py `_cal_grad`, guarded by `model.actor_bc_lambda > 0`,
  default 0.0 = branch fully skipped, no behavior change): REUSES the model
  update's replay batch and its posterior states (no separate encode pass) --
  `lambda_bc * mean(-log_prob(actor(feat_t.detach()), a_demo_t))` over
  demo-flagged, non-episode-final rows (feat detached: BC shapes the ACTOR
  only). Pairing: post-sample-shift the action executed at data-row t is
  `data["action"][:, t+1]` (same storage row as the obs). Zero-demo batches are
  safe (mask-sum clamped). Lambda lives in a non-persistent buffer so the
  compiled graph reads decayed values without recompiling.
- Schedule (hardcoded): lambda linear from actor_bc_lambda to 0.1 over the
  first 500k ONLINE env steps (trainer threads `online_step` = step -
  post-prefill origin into agent.update), then constant 0.1. Logged:
  `train/actor_bc_lambda`, `train/actor_bc_loss`, `train/actor_bc_frames`.
- Config: `model.actor_bc_lambda` (model/_base_.yaml, default 0.0) via the
  `${oc.select:env.actor_bc_lambda,0.0}` cross-package hook;
  `configs/env/genesis_place_bc.yaml` = genesis_place_shaped clone (dense
  bank, shaping, reinject 200k, dup 5) + `actor_bc_lambda: 1.0`. Resolution
  verified: shaped/pick/dmc_vision -> 0.0, place_bc -> 1.0.
- **DEMO ACTION-CONVENTION FIX (affects ALL demo runs from now on):** the npz
  stores actions backward-in-row (row t = action that PRODUCED obs_t), but
  trainer.begin stores online rows forward-in-row (action chosen AT obs_t) and
  Buffer.sample() shifts one step back. Loading npz as-is (all runs before
  2026-08-04) fed demo prev-actions ONE STEP STALE into RSSM.observe.
  `demo_prefill._load_episode` now shifts demo actions up by one (final row =
  zero placeholder, like online done rows), making demo rows convention-
  identical to online rows. Unit-checked against a raw npz. Prior demo-prefill
  runs (pick s0, place v1-v3) carried this off-by-one.
- Verified (GPU smoke, env_num=2, steps=prefill+2062, lambda=1, seed 0,
  runs/genesis_place_bc_smoke): prefill 205 eps / 103,938 transitions; 557
  updates; actor_bc_loss logged every 50 steps and DECREASING 5.23 -> 1.41
  (first-3 mean 5.25 -> last-3 mean 1.58); lambda matches 1 - 0.9*online/500k
  to 1e-6 at every snapshot; actor_bc_frames ~1007/1008 (buffer almost all
  demo at this stage); NO NaN/Inf in any logged metric; run completed exit 0,
  latest.pt saved. (Console log rounds actor_bc_lambda to 1.0 -- full
  precision is in metrics.jsonl/tensorboard.)

Suggested full launch (place + BC, same budget as run 3):

    cd ~/workspace/r2dreamer && MUJOCO_GL=egl \
      GENESIS_PICKAPLACE_ROOT=/home/j/workspace/genesis_pickaplace \
      nohup setsid ./.venv/bin/python train.py env=genesis_place_bc \
      env.demo_dir=/home/j/workspace/genesis_pickaplace/baselines/demonstrations/genesis_place \
      env.env_num=8 env.steps=1.11e6 buffer.max_size=7e5 \
      trainer.pretrain=1000 seed=0 logdir=runs/genesis_place_bc_s0 \
      > runs/genesis_place_bc_s0/run.log 2>&1 &

  (steps = ~104k dup-5 prefill + ~1.0M online; mkdir the logdir first.)

## Eval action-conditioning audit (2026-08-08): NO BUG -- proven, documented

Question raised: eval_genesis.py's pack() builds transitions WITHOUT an
"action" key while trainer-stored TensorDicts include one -- does that starve
the RSSM of the previous action during eval? **Answer: NO. The previous action
never travels through the transition dict in EITHER path.**

Proven mechanics (test_action_conditioning.py (repo root), run against the
real genesis_pick_demo_s0 weights, P1-P4 all PASS):
- `Dreamer.act` (dreamer.py ~262) reads the previous action from
  `state["prev_action"]` -> `rssm.obs_step(prev_stoch, prev_deter,
  prev_action, embed, is_first)`, and returns the new state with
  `prev_action = <the action it just emitted>`. Both loops thread that state:
  trainer.begin `act, agent_state = agent.act(trans.clone(), agent_state, ...)`
  and eval_genesis `act, state = agent.act(trans, state, ...)`. Zeros only at
  t=0 (`get_initial_state`), and obs_step re-zeroes prev_action wherever
  is_first is set -- identical conventions.
- The obs-dict "action" key is never consumed: the encoder sees only
  cnn_keys='image' (mlp_keys='$^'; MultiEncoder also drops reward/is_*/log_*),
  and in trainer.begin the trans passed to act() does not even HAVE an action
  key yet (`trans["action"] = act * ~done` is assigned AFTER act, for replay
  storage only). P1: injecting a garbage action key into the eval trans ->
  bit-identical action and recurrent state. P2: perturbing state["prev_action"]
  -> max|d_deter| 0.72 (it IS load-bearing, via state).
- Gotcha found while proving (harness itself unaffected): `Dreamer.preprocess`
  mutates trans["image"] IN PLACE (u8 -> f32/255) -- never call act() twice on
  the same trans object. Both loops build a fresh trans per step.

Action-sampling parity (user directive), call sites documented:
- Training collector: trainer.py `begin()` -> `agent.act(trans.clone(),
  agent_state, eval=False)` -> dreamer.py `act()`:
  `action_dist.rsample()` -- the collector SAMPLES.
- eval_genesis.py `--mode sample` (default) -> `agent.act(trans, state,
  eval=(args.mode == "mode"))` -> eval=False -> the SAME rsample() line.
  `--mode mode` -> dist.mode (= trainer.eval's eval=True path, which genesis
  never uses in-process, eval_episode_num=0).
- P4: RNG-matched `act(eval=False)` == `actor(feat).rsample()` bit-exact, and
  `act(eval=True)` == `actor(feat).mode`.

Harness fix that DID land (eval_genesis.py): outcome classification is now
scope-aware. In scope='place' the can starts held, so 'picked' is trivially
granted -- the old eval reported place timeouts as "picked 1.00". Place
outcomes are now placed_v2 / tipped / timeout (metrics.json carries scope +
the scope's success key).

Re-eval, 15 eps, sample, seed 0, demo ICs (runs/<run>/policy_eval_20260808):
- genesis_pick_demo_s0 (max-steps 1200): picked 1/15 (uid331), tipped 2/15
  (258, 269), timeout 12/15 -- per-episode outcomes IDENTICAL to the prior
  policy_eval baseline, independently confirming no conditioning bug existed.
- genesis_place_bc_s0 (max-steps 600): placed_v2 0/15, tipped 0/15, timeout
  15/15 (hold-forever equilibrium unchanged; previously mislabeled picked 1.00).

## Buffer parity test (2026-08-08): test_buffer_parity.py

Standalone structural test (repo root; the test that would have caught the
2026-08-04 stale-action bug). Collects ONE real episode through the normal
online path (make_envs -> ParallelEnv -> trainer.begin storage lines verbatim,
env_num=1, time_limit 300) and ingests ONE saved demo (shortest rewarded npz)
through prefill_from_npz, then compares the rows AS STORED: identical column
key sets/dtypes/shapes; forward-in-row action convention with zero action on
the episode-final row, demo actions checked ELEMENTWISE against the raw npz
(buffer[t] == npz[t+1] -- the _load_episode shift); demo actions within
[-1,1] vs online unclamped-but-same-units rsamples; image u8 0..255; reward
zero on is_first, demo reward only on the terminal row; is_first/is_last/
is_terminal patterns; episode/is_demo columns. Prints first/last-3 rows
side-by-side. Run:

    cd ~/workspace/r2dreamer && MUJOCO_GL=egl \
      GENESIS_PICKAPLACE_ROOT=/home/j/workspace/genesis_pickaplace \
      ./.venv/bin/python test_buffer_parity.py

Status 2026-08-08: ALL CHECKS PASS (online 301 rows vs demo
genesis-0243-172.npz 172 rows). Must live under `if __name__ == "__main__"`
(spawn workers re-import __main__).

## Reward-scale lever (built + verified 2026-08-09; run pick_dH_v4_r100_s0)

User directive: put the pick reward effectively at +100 vs the ~0.005/state
twohot reward-head leak (diagnosis #2). The v3_ent run (pick_dH_v3_ent_s0,
act_entropy back at 3e-4) was killed for this; act_entropy stays at the v2
default 3e-5 (user confirmed).

- `env.reward_scale` (default 1.0 = no behavior change): multiplies (a) EVERY
  env-side reward in `envs/genesis.py` GenesisPick.step (applied AFTER the
  action_repeat sum; getattr-guarded for stale pickles) and (b) demo rewards in
  `demo_prefill._load_episode` (applied at load, BEFORE downsample/shift) --
  the SAME factor both places so demo and online rows encode one coherent
  reward function. Threaded via `envs/__init__.py` `config.get("reward_scale",
  1.0)`; `configs/env/genesis_pick_v2.yaml` sets **reward_scale: 100.0**.
  Prefill stats now report `reward_scale` + `terminal_reward_values`.
- Return normalizer absorbs the magnitude by design: ReturnEMA (networks.py)
  divides by the 5%/95% return-range EMA with `clip(min=1.0)` -- at scale 100
  the range grows past the 1.0 clamp and normalizes through, instead of the
  clamp swallowing the sparse signal at scale 1.
- Verified (scratchpad validate_reward_scale.py + probe_env_scale.py + GPU
  smoke runs/pick_v4_smoke, all PASS):
  1. Demo side: all 91 npz through _load_episode(downsample=4,
     reward_scale=100) -> **79/79 rewarded terminals at exactly 100.0**
     (23,719 rows); default path bit-identical to pre-patch; prefill print in
     the smoke shows `reward_scale: 100.0, terminal_reward_values: [100.0]`.
  2. Env side: LIVE CPU world probe -- GenesisPick(reward_scale=100,
     action_repeat=1) reset to uid 232, open-loop replay of the demo's raw
     actions -> pick grant at step 277 returned **+100.0** (log_picked 1.0).
     Plus stubbed-env unit checks (scale 100 -> 100.0, default -> 1.0,
     pre-patch pickled instance -> 1.0 via getattr).
  3. No NaN: full train.py smoke (env_num=2, prefill + ~700 online agent
     steps, pretrain 200, exit 0): 0 NaN/Inf across all metrics.jsonl
     snapshots; train/loss/rew 5.0 finite; train/data/reward_sum 700 on 7
     demo frames (=100 each); train/ret_replay_max 100.0 while
     value_replay_mean 0.08 (sane -- no leak blow-up).
  4. Hydra: v2 resolves reward_scale 100.0 / act_entropy 3e-5; genesis_pick
     (v1) and place configs have no key -> default 1.0 (existing runs
     unaffected).

Long run relaunched 2026-08-09 (detached nohup setsid, **pid 684204**),
log runs/pick_dH_v4_r100_s0_launch.log:

    train.py env=genesis_pick_v2 env.env_num=6 env.steps=6e6
      env.demo_reinject_every=300000
      env.demo_dir=/home/j/workspace/dreamerv3-torch/demonstrations/genesis_pick
      buffer.max_size=450000 trainer.pretrain=1000 seed=0
      logdir=runs/pick_dH_v4_r100_s0

Watch: episode/score should show 100.0 on picks; train/ret_005..095 will
rescale over the first ~1/alpha updates; same watch keys as v2 (action_entropy
must not ratchet, reward_frames ~3+, eval periodic checkpoints).

## v4 train-eval gap RESOLVED (2026-08-09): predicate gaming, not eval bug

The "~30% train_picked vs 1/15 eval" gap was METRIC INFLATION — but not sticky
`_granted`/log_* (audited clean: FullTaskEnv.reset clears _granted, GenesisCanEnv
.reset clears _picked, adapter emits flags only on done; 0/6079 episodes disagree
between train_picked and score>=100). The picked PREDICATE was gamed: `can_z >
pick_z AND grip COMMANDED closed` never checks the can is held, and the v4 policy
learned to whack the can airborne with fingers closed — final-window "picks" are
77/102 at 2-9 agent steps (8-36 sim steps, physically impossible grasps), and 148
episodes scored 200/400 (picked+placed[+contact] granted the same instant the
flung can crossed the shelf). Honest length-filtered final rate ~= 0.03-0.05,
fully consistent with eval 1/15 (0.067) — no train-eval anomaly remains.
Hypothesis B untestable: the periodic save overwrites latest.pt (only latest.pt
in the run dir). FIX (genesis_pickaplace baselines/genesis_can_env.py): picked
now requires (z > pick_z, grip closed, |eef-can| < 0.20) sustained 10 consecutive
frames — a held can rides the eef at ~0.146 m sub-mm-stable (measured, uid232);
a batted can separates ballistically. Regression: uid232 raw replay grants at 286
(old 277, +9 = the sustain window), +100.0. NOTE: genesis_vec_env.py:265 still
carries its own un-guarded copy of the old predicate; offline demo-measurement
copies (replay/batch harness) are not RL-gameable and were left alone. All v4
train_picked/score history predates the fix — read it as fling-inflated.

## wandb wiring (built 2026-08-10; entity jambotime, project r2dreamer_genesis)

wandb installed into .venv (0.28.1; it was absent — earlier "import wandb"
successes from this repo were cwd-shadowing genesis_pickaplace's `wandb/` run
dir, a namespace-package ghost with no attributes). Creds: WANDB_API_KEY env
var, verified against api.wandb.ai (default entity jambotime).

- `eval_genesis.py --wandb` (default OFF): after metrics.json is written, logs
  the summary scalars (`eval/<success_key>`, tipped, timeout, mean_steps,
  mean_reward, episodes) + up to 6 episode mp4s as wandb.Video to a run named
  `<run>-eval[-step<N>]`, job_type=eval, then finishes. ENTIRELY inside
  try/except — wandb failure can never sink an eval (per-video try too).
- Checkpoints now carry `step`: trainer.save_checkpoint(agent, step=step) and
  train.py's end-of-run save (`step` = env.steps) — so FUTURE evals get the
  `-step<N>` name suffix; all pre-2026-08-10 latest.pt lack it (name = `<run>-eval`).
- `sync_runs_to_wandb.py`: one wandb run per `runs/*/` with metrics.jsonl
  (name = dir name, config = .hydra/config.yaml unresolved), full scalar
  history uploaded step-keyed via a CUSTOM step metric `env_step`
  (define_metric) — immune to non-monotonic steps from relaunches, which
  wandb's internal step would silently drop. Idempotent: `.wandb_synced`
  marker (run_id + synced line count) — reruns skip finished runs and RESUME
  grown ones (safe on live runs; marker checkpointed every 20k lines).
  `--only NAME...` / `--force` flags.
- Full backfill run 2026-08-10: all 22 run dirs (v1/v2/v4/v5 pick, place
  v2-v8b, smokes) synced — see runs/sync_all_wandb.log.
- v2 recheck re-run WITH wandb (15 eps, sample, max-steps 1200, cuda, out
  policy_eval_20260810): picked 0.00 / tipped 0.33 / timeout 0.67, mean_steps
  227 — per-episode outcomes IDENTICAL to the hardened recheck (same seed ->
  same uid draw + deterministic sampled rollouts on this box). 6 episode
  videos + scalars in wandb run `pick_dH_v2_s0-eval`
  (runs/1h1ga0ix); console log runs/v2_recheck_wandb.log.

Browse: https://wandb.ai/jambotime/r2dreamer_genesis (training histories under
job_type train-sync, x-axis env_step; evals under job_type eval).

## ManiSkill-parity pick run (built + launched 2026-08-10; run pick_msparity_s0)

Recipe = the working ManiSkill run's pillars mapped onto genesis (see
../dreamerv3-torch/MANISKILL_VS_GENESIS.md for the delta audit):

- **Demos: IDLE-PRUNED pick set.** `episodes_pick_phase_dppruned` (66 eps) has
  NO images key -> sourced `baselines/episodes_pick_pruned_img` (67 eps, images
  present) via `baselines/rl/to_dreamer_demos.py --scope pick` (r2dreamer venv)
  -> `~/workspace/dreamerv3-torch/demonstrations/genesis_pick_pruned`: **67
  episodes, 67 rewarded pick terminals** (one +1 each, truncated at the pick
  grant). Through `demo_prefill._load_episode(downsample=4, reward_scale=100)`:
  67/67 terminals survive at exactly 100.0, 9,948 rows, downsampled lengths
  **44/115/632 min/med/max agent steps** (asserted 2026-08-10). NOTE the
  coordinator's "demos ~35 downsampled" was off — median is 115, i.e. just OVER
  the new tl=100, which is the SAME regime as the working MS run (teleop demos
  83-133 steps vs tl 100; learned policies find faster paths than demos).
- **`configs/env/genesis_pick_v3.yaml`** = v2 clone with: `time_limit: 400` sim
  steps (// action_repeat 4 = **100 AGENT steps**, MS's exact tl — the yaml key
  is in SIM steps, `wrappers.TimeLimit(time_limit // action_repeat)`);
  `act_entropy: 3e-4` (STOCK — MS shows entropy self-collapses when the signal
  is strong; v2's 3e-5 was compensating for the broken critic, since fixed by
  reward_scale 100 + the hardened predicate); `train_ratio: 512` (update every
  1024/512*4 = 8 sim steps = 2 agent steps); reward_scale 100 / repeat 4 /
  downsample 4 / horizon 333 / reinject 300k inherited from v2.
- **Smoke gotcha (affects all short runs):** train.py's "trainer starts at step
  N" print is buffer.count(), but trainer.begin starts at `buffer.count() *
  action_repeat` (= 39,936 sim steps for this prefill). env.steps below that ->
  the while loop NEVER RUNS and the run exits 0 "cleanly" with only latest.pt.
  Two smokes silently no-opped this way before being caught.
- **Smoke PASS** (env_num=2, steps=44000 = prefill*4 + ~4k online sim,
  pretrain 200, update_log_every 50, runs/pick_msparity_smoke): 0 NaN/Inf in
  107 snapshots; 25 online episodes ALL <=100 agent steps (tips end early,
  timeouts at exactly 100 — timeout dilution killed vs v2's 300); demo
  terminals sampled at exactly 100.0 (reward_sum = 100*reward_frames every
  snapshot); **~6.5 rewarded frames/1024-batch** (pruned set is ~2x denser than
  the 91-demo set's ~3.4); loss/rew 5.01 -> 0.20; entropy 9.14 at init (watch
  for the MS-style collapse toward ~-2 nats as updates accumulate).

Launched 2026-08-10 (detached nohup setsid, **pid 1057087**), log
runs/pick_msparity_s0_launch.log:

    train.py env=genesis_pick_v3 env.env_num=6 env.steps=3e6
      env.demo_reinject_every=300000
      env.demo_dir=/home/j/workspace/dreamerv3-torch/demonstrations/genesis_pick_pruned
      buffer.max_size=450000 trainer.pretrain=1000 seed=0
      logdir=runs/pick_msparity_s0

Watch: `train/action_entropy` MUST fall (the MS fingerprint: commit before the
first online success) — if it ratchets up like v1/v2, the parity hypothesis is
dead; `episode/score` 100.0 on honest picks (predicate hardened 2026-08-09,
fling-proof); `train/data/reward_frames` ~6+; eval via eval_genesis.py --wandb
(periodic latest.pt carries step).

## Delta-joint action variant (built + replay-gated 2026-08-10; NOT launched)

MANISKILL_VS_GENESIS #4: the working MS run used pd_ee_delta_pos — delta
position-targets are self-correcting under entropy noise, absolute joint
targets turn sampled-action exploration into arm thrash (user-observed).
Cheapest correct geometry = delta-JOINT at the adapter level.

- `envs/genesis.py` GenesisPick: new `action_mode` 'absolute' (default,
  byte-identical — the key is absent from all older configs, config.get
  defaults it) | 'delta_joint': arm dims in [-1,1] are per-SIM-step
  joint-target deltas of a*delta_cap rad integrated onto a persistent target
  (init = measured qpos at reset via `sync_delta_target()`; clipped to the
  pick_env ARM_LO/HI envelope; leashed to measured qpos within 3*cap —
  CartesianCanEnv's setpoint-leash pattern). Grip dim stays ABSOLUTE
  ([-1,1] -> 0..1). Under action_repeat N the target integrates a*cap on EACH
  of the N sim steps (ramped targets). Threaded via envs/__init__.py
  (`env.action_mode`, `env.delta_cap`); eval_genesis.reset_to_uid re-seeds the
  target (getattr-guarded no-op in absolute mode).
- **Cap calibration** (episodes_pick_pruned_img, 118,194 frames):
  **delta_cap 0.04** rad/sim-step over COMMANDED-target deltas — global p99
  0.0249, max per-dim p99 0.0307 (joint 4), 0.17% of demo values clip (max
  ever 0.059). Leash 3*cap = 0.12 covers the demos' |cmd − q| PD lead
  (p99 0.126). (Measured-q deltas: global p99 0.0203, per-dim max 0.0292.)
- **Demos**: to_dreamer_demos.py `--action-encoding delta_joint --delta-cap
  0.04 --grant-slack 48` (+ scope pick) ->
  `~/workspace/dreamerv3-torch/demonstrations/genesis_pick_pruned_delta`:
  67 eps, 67/67 rewarded terminals at exactly 100.0 through
  _load_episode(downsample=4, reward_scale=100), 10,752 downsampled frames,
  lengths 56/127/644 min/med/max agent steps. Downsample x4 composition is
  EXACT by construction: mean-pooled per-frame deltas telescope to
  (cmd_{t+4}−cmd_t)/(4*cap) and the adapter re-integrates a*cap per sim step
  (open-loop integration reconstructs the joint trajectory to 3e-4 rad).
- **Two gate-caught design lessons** (both encoded in the converter now):
  (1) measured-q deltas FAIL replay — the replayed arm chases its own PD lag
  (~40 raw frames behind by the lift; 0/3 then 1/3) — deltas must come from
  the COMMANDED targets (npz actions), whose integration reproduces the
  validated commanded replay; (2) tapes cut at the recorded grant frame end
  before the hardened predicate (2026-08-09, +10-frame sustain) can fire —
  `--grant-slack 48` keeps 48 raw frames of the demo's own continued lift and
  moves the +1/terminal to the tape end (benign: online pick episodes
  terminate at the grant, so the higher-lift demo states contradict nothing).
- **REPLAY GATE (non-negotiable) PASS 3/3**: open-loop replay of the exact
  training rows (_load_episode downsample=4) through
  GenesisPick(action_mode='delta_joint', action_repeat=4, reward_scale=100) —
  uid 232 picks @60/71 agent steps (+100, terminated), 242 @60/71, 243 @44/56.
- Known blemish (pre-existing, shared with the v3 abs set): **uid 331's demo
  terminal is a spurious grant** — its can settles ON the shelf at z=0.170 >
  pick_z (only 1/67; census run), so the recorded old-predicate "pick" fires
  with the can untouched while the grip cmd drifts past 0.3. Kept for
  apples-to-apples with v3 (same 67 episodes, only the encoding differs).
- `configs/env/genesis_pick_v4_delta.yaml` = v3 clone (tl 100 agent steps,
  reward_scale 100, stock act_entropy 3e-4, train_ratio 512, repeat 4 +
  downsample 4, horizon 333, reinject 300k) + `action_mode: delta_joint` +
  `delta_cap: 0.04`. Hydra verified: v4_delta resolves both keys; v3/v1/place
  configs lack them -> absolute (existing runs untouched).

Ready-to-launch (GPU currently owned by pick_msparity_s0 — do NOT start until
it is done or killed; mkdir the logdir first):

    cd ~/workspace/r2dreamer && MUJOCO_GL=egl \
      GENESIS_PICKAPLACE_ROOT=/home/j/workspace/genesis_pickaplace \
      nohup setsid ./.venv/bin/python train.py env=genesis_pick_v4_delta \
      env.env_num=6 env.steps=3e6 env.demo_reinject_every=300000 \
      env.demo_dir=/home/j/workspace/dreamerv3-torch/demonstrations/genesis_pick_pruned_delta \
      buffer.max_size=450000 trainer.pretrain=1000 seed=0 \
      logdir=runs/pick_delta_s0 > runs/pick_delta_s0/run.log 2>&1 &

(Prefill ~10.8k rows spends ~43k sim steps of env.steps. Watch the same keys
as v3: train/action_entropy must FALL, episode/score 100.0 on honest picks,
train/data/reward_frames ~6+.)

## Next (stage 3, NOT built)

- H4 leg proper: with/without-prefill x3 seeds + shuffled-action neg control
  (plan §7 rung 6); honesty protocol per standing directive.
- Demo persistence beyond eviction: BUILT (env.demo_reinject_every, section
  above); decide the cadence per-run if the demo signal proves load-bearing.
- Watch keys: `episode/train_picked`, `train/data/reward_frames`, `train/loss/rew`,
  `episode/score` in runs/genesis_pick_demo_s0 (tensorboard + metrics.jsonl).

## 2026-08-10 (night): v4_delta verdicts + v5_delta launch (the action-space fix stack)

**msparity (v3, absolute, ManiSkill-parity settings) — VERDICT: FAIL, killed at
850k/3M.** 0 picks in 2479 episodes; entropy never stably collapsed (oscillated
-5.7 <-> +9, was +6.8 at kill). The MS fingerprint (entropy collapse BEFORE
first success, then sustained) never appeared. Absolute joints + sampled
exploration = thrash; the recipe does not transplant on this action geometry.

**pick_delta_s0 (v4_delta) — killed at ~320k/3M after the strongest-yet
transient**: train picked 0.24 @128k with entropy collapsed to -5, then decay
(0.15 -> 0.08) as entropy re-ratcheted; the 300k demo re-inject re-collapsed
entropy (demo-supported oscillation). Evals 0/10, 0/10: the policy LUNGES —
tips-in-1-2-agent-steps forensics traced to forearm strikes at saturated speed
(69 deg/s), NOT env artifacts (upright spawns verified, adapter target-sync
verified, hardened predicate verified).

**Root causes found (three, compounding), all fixed in v5_delta:**
1. `bounded_normal` bounds the MEAN only — samples reached +-4
   (train/action_max 3.8/-4.3); env executes clip(a) but buffer/imagination
   keep the raw sample (fictional-action dynamics, the v6-v13 bug family on the
   policy side). Fix: `bounded_normal_clipped` (distributions.py) — projects
   sample AND rsample (rsample is what collect + imagination actually call;
   stock `Bound` never covered it). Opt-in via env.actor_dist hook in
   model/_base_.yaml; upstream benchmarks untouched. dv3 checked NOT affected
   (ContDist absmax=1.0, models.py:278).
2. delta_cap 0.04 = 1.5x demo p99 speed. v5: cap 0.025 == demo p99 (44 deg/s),
   1.31% demo-frame clip, REPLAY GATE 3/3 (replay_gate.py — now a permanent
   script; 232@60, 242@59, 243@44 agent steps). Demo set:
   demonstrations/genesis_pick_pruned_delta25. delta_leash_mult now
   configurable (leash must stay >= absolute PD-lead 0.126 -> mult 5).
3. v4_delta silently inherited v3's act_entropy 3e-4 (10x the v2 recipe). v5:
   3e-5.

**RUNNING: runs/pick_delta25_s0** (v5_delta, full GPU, seed 0, 3M). Health keys:
train/action_max must stay <= 1.0 now; entropy collapse + train_picked as
before. Cluster launches should use CONFIG=genesis_pick_v5_delta with the
delta25 demo dir (rsync both).

**2026-08-10 ~23:20 update — v5-no-BC stalled, relaunched WITH actor-BC.**
pick_delta25_s0 (v5, no BC): entropy rose monotonically to the ceiling (5.4 ->
9.8 -> 9.9) with picked_last100 0.000 through the 300k reinject, killed at
~420k. Diagnosis: EXPLORATION STARVATION -- at cap 0.025 with bounded samples,
random motion is too gentle to stumble into sustained-hold picks (delta_s0's
0.04-cap lunges were accidentally generating grasp encounters), so advantage
stays ~0 and the entropy bonus is the only actor gradient. Symmetric failure to
the ratchet: too-hot actions find reward but destroy the arm; too-cold never
find it. The demos must supply the reach-and-grasp prior directly ->
**RUNNING: runs/pick_delta25bc_s0** = v5 + env.actor_bc_lambda=1.0 (linear ->
0.1 over 500k, then held; BC on demo-flagged rows). NOTE: hydra struct mode
rejects undeclared env.* CLI keys -- actor_bc_lambda: 0.0 is now DECLARED in
the v5 yaml so the CLI override works. Watch: entropy should now FALL from the
start (BC gradient opposes it); picked_last100 nonzero by ~300k or rethink.

**2026-08-11 — actor-BC PROHIBITED (user): design confound.** pick_delta25bc_s0
ABORTED at ~160k despite the healthiest-yet signature (entropy -5.5 from the
start, picked 0.08 @153k): actor-BC imitates the demonstrator's actions, which
is exactly what the H4 world-model arm is contrasted AGAINST — the WM must
consume demos as dynamics/reward DATA only. actor_bc_lambda stays 0 in all
genesis runs (yaml comment updated). Its early curve is still INFORMATIVE as a
diagnostic: with an action prior the recipe learns fast, confirming the
bottleneck is exploration/credit, not the world model.
**RUNNING: runs/pick_delta25d4_s0** = v5 (no BC) + demo_duplicate=4 +
demo_reinject_every=150k — non-confounding demo-density lever (demos as data,
~43k of 450k buffer rows). If entropy pegs at ceiling with 0 picks again by
~400-500k, remaining non-confounding levers: act_entropy 1e-5 or 0 (min_std 0.1
floor keeps exploration alive), longer budget, train_ratio.

**2026-08-11 — SILENT-DEFAULT BUG #7: eval_genesis evaluated delta policies in
ABSOLUTE mode.** The env construction passed only action_repeat; action_mode/
delta_cap/leash/reward_scale silently defaulted -> every delta-run eval executed
delta actions as absolute joint targets (a different MDP). Symptom that cracked
it: "tipped in 1-2 agent steps" at cap 0.025 = physically impossible (<=0.1 rad
of motion); faithful manual repro showed no tips; the eval videos' lunges were
absolute-mode thrash, not the policy. VOID results: pick_delta_s0 evals 1+2
(0/10 both), pick_delta25d4_s0 eval 1 (0/15). The earlier "policy lunges at the
can" forensic conclusion was built on these void evals -- the cap-0.025 and
bounded-dist changes remain independently justified (demo-speed stats; buffer
storing unexecuted +-4 samples), but delta_s0's true eval skill was never
measured (checkpoint retained: runs/pick_delta_s0/latest.pt ~170k). Fixed:
eval_genesis now passes ALL action-semantics params from the run's own hydra
config and prints them; d4 re-eval launched. Doctrine reminder (7th sighting):
control mode NEVER defaults -- it travels with the artifact or the config.
