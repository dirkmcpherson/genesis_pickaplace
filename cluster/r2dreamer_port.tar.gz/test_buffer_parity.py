"""Structural parity test: online-collected rows vs demo-prefill rows IN THE BUFFER.

This is the test that would have caught the 2026-08-04 stale-action bug (demo
npz stores actions backward-in-row; trainer.begin stores forward-in-row): it
collects ONE real episode from the sim through the normal online collection
path (make_envs -> ParallelEnv -> the trainer.begin storage lines, verbatim)
and ingests ONE saved demo episode through the prefill path
(demo_prefill.prefill_from_npz), then compares the two AS STORED:

  - column key set, dtypes, shapes
  - action placement convention (row t = action chosen AT obs_t; zero action
    on the episode-final row; demo rows checked ELEMENTWISE against the raw
    npz: buffer[t] must equal npz[t+1], i.e. the _load_episode shift happened)
  - action scaling (demo commands within [-1,1]; online actions finite,
    same units -- bounded_normal rsample is unclamped by design, env clips)
  - image dtype/range (uint8 0..255, not pre-normalized)
  - reward placement (zero on is_first; demo reward only on the terminal row)
  - is_first / is_last / is_terminal patterns (first row, final row, terminal
    only on final row) + episode/is_demo columns

Standalone (fresh process; builds one Genesis world inside the spawn worker):

    cd ~/workspace/r2dreamer && MUJOCO_GL=egl \
      GENESIS_PICKAPLACE_ROOT=/home/j/workspace/genesis_pickaplace \
      ./.venv/bin/python test_buffer_parity.py

Runtime ~1-2 min (world build ~20-35 s + one random-policy episode; the online
episode is bounded by a 300-step TimeLimit override -- the wrapper path is the
normal one, only the horizon is shortened for test speed).
"""
import os
import pathlib
import sys
import tempfile

os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("GENESIS_PICKAPLACE_ROOT", "/home/j/workspace/genesis_pickaplace")

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import numpy as np
import torch
from omegaconf import OmegaConf

import tools
from buffer import Buffer
from demo_prefill import prefill_from_npz
from dreamer import Dreamer
from envs import make_envs

DEMO_DIR = pathlib.Path(
    os.environ.get("DEMO_DIR", "/home/j/workspace/dreamerv3-torch/demonstrations/genesis_pick")
)
CFG = HERE / "runs/genesis_pick_demo_s0/.hydra/config.yaml"  # any resolved genesis_pick config

def main():
    tools.set_seed_everywhere(0)
    cfg = OmegaConf.load(CFG)
    cfg.device = "cpu"
    cfg.model.compile = False
    cfg.env.env_num = 1
    cfg.env.time_limit = 300          # bound the random-policy episode (path unchanged)
    cfg.buffer.max_size = 20000
    cfg.buffer.device = "cpu"
    cfg.buffer.storage_device = "cpu"


    def storage_rows(buf):
        """(T, keys) TensorDict of column 0 of the (time, columns) storage."""
        st = buf._buffer._storage._storage
        n = buf.count()
        return st[:n, 0]


    # ---------------------------------------------------------------- online path
    print("[parity] building 1 env + agent (world builds in the spawn worker)...")
    train_envs, _, obs_space, act_space = make_envs(cfg.env)
    agent = Dreamer(cfg.model, obs_space, act_space).to("cpu")  # random weights: conventions only

    buf_online = Buffer(cfg.buffer)
    # ---- trainer.begin collection loop, storage lines VERBATIM (trainer.py) ----
    episode_ids = torch.arange(cfg.env.env_num, dtype=torch.int32)
    online_is_demo = torch.zeros(cfg.env.env_num, 1, dtype=torch.bool)
    done = torch.ones(cfg.env.env_num, dtype=torch.bool)
    agent_state = agent.get_initial_state(cfg.env.env_num)
    act = agent_state["prev_action"].clone()
    rows_stored = 0
    for _ in range(cfg.env.time_limit + 10):
        trans, step_done = train_envs.step(act.detach(), done)
        trans = trans.to(agent.device, non_blocking=True)
        done = step_done.to(agent.device)
        act, agent_state = agent.act(trans.clone(), agent_state, eval=False)
        trans["action"] = act * ~done.unsqueeze(-1)
        trans["stoch"] = agent_state["stoch"]
        trans["deter"] = agent_state["deter"]
        trans["episode"] = episode_ids
        trans["is_demo"] = online_is_demo
        buf_online.add_transition(trans.detach())
        rows_stored += 1
        if done[0] and rows_stored > 1:  # first stored done row = episode end
            break
    assert done[0], "online episode did not finish within time_limit+10 steps"
    on = storage_rows(buf_online)
    print(f"[parity] online episode collected: {rows_stored} rows "
          f"(is_terminal[-1]={bool(on['is_terminal'][-1, 0])})")
    train_envs.envs[0].close()

    # ---------------------------------------------------------------- demo path
    files = sorted(DEMO_DIR.glob("*.npz"))
    assert files, f"no demo npz files in {DEMO_DIR}"
    best = None
    for f in files:  # shortest REWARDED demo (keeps the test small but exercises reward rows)
        with np.load(f) as d:
            T, r = len(d["reward"]), float(d["reward"][-1])
        if r > 0 and (best is None or T < best[1]):
            best = (f, T)
    demo_file, demo_T = best
    print(f"[parity] demo episode: {demo_file.name} ({demo_T} frames, rewarded terminal)")
    with np.load(demo_file) as d:
        raw_action = d["action"].astype(np.float32)  # npz convention: backward-in-row

    with tempfile.TemporaryDirectory() as td:
        os.symlink(demo_file, pathlib.Path(td) / demo_file.name)
        cfg_demo = OmegaConf.merge(cfg, OmegaConf.create({"env": {"demo_dir": td, "demo_duplicate": 1}}))
        buf_demo = Buffer(cfg.buffer)
        info = prefill_from_npz(buf_demo, agent, cfg_demo)
    assert info["transitions_added"] == demo_T and info["padding_frames"] == 0, info
    de = storage_rows(buf_demo)

    # ---------------------------------------------------------------- comparisons
    failures = []


    def check(name, cond, detail=""):
        print(f"  {'PASS' if cond else 'FAIL'}  {name}" + (f"  [{detail}]" if detail else ""))
        if not cond:
            failures.append(name)


    print("\n[parity] 1. column key set / dtypes / shapes")
    kon, kde = set(on.keys()), set(de.keys())
    check("identical column key sets", kon == kde, f"only-online={kon - kde} only-demo={kde - kon}")
    for k in sorted(kon & kde):
        check(f"{k}: dtype {on[k].dtype} shape {tuple(on[k].shape[1:])}",
              on[k].dtype == de[k].dtype and on[k].shape[1:] == de[k].shape[1:],
              f"demo: {de[k].dtype} {tuple(de[k].shape[1:])}")

    print("\n[parity] 2. action convention (forward-in-row; zero on final row)")
    check("online: final (is_last) row action is ZERO", not on["action"][-1].any())
    check("demo:   final (is_last) row action is ZERO", not de["action"][-1].any())
    # THE stale-action catcher: buffered demo action[t] must be the npz action[t+1]
    shifted_ok = np.allclose(de["action"][:-1].numpy(), raw_action[1:], atol=0)
    check("demo:   buffer action[t] == npz action[t+1] elementwise (shift applied)", shifted_ok)
    check("demo:   raw npz row0 action was zero (backward convention in the file)",
          not raw_action[0].any())
    stale = np.allclose(de["action"].numpy(), raw_action, atol=0)
    check("demo:   buffer is NOT the unshifted npz (stale convention)", not stale)

    print("\n[parity] 3. action scaling / units")
    d_max = de["action"].abs().max().item()
    o_max = on["action"].abs().max().item()
    check(f"demo action range within [-1,1] (max|a|={d_max:.3f})", d_max <= 1.0 + 1e-6)
    check(f"online action finite, same units (max|a|={o_max:.3f}; bounded_normal "
          "rsample is unclamped by design, env clips to [-1,1])",
          torch.isfinite(on["action"]).all() and o_max < 8.0)

    print("\n[parity] 4. image dtype / range")
    for name, r in (("online", on), ("demo", de)):
        img = r["image"]
        check(f"{name}: image uint8, range [{int(img.min())},{int(img.max())}] in 0..255, not pre-normalized",
              img.dtype == torch.uint8 and int(img.max()) > 1)

    print("\n[parity] 5. reward placement")
    check("online: reward zero on is_first row", float(on["reward"][0, 0]) == 0.0)
    check("demo:   reward zero on is_first row", float(de["reward"][0, 0]) == 0.0)
    check("demo:   nonzero reward ONLY on the terminal row",
          (de["reward"][:-1] == 0).all() and float(de["reward"][-1, 0]) > 0)
    check("online: reward rows co-located with their obs (sum={:.1f})".format(
          float(on["reward"].sum())), True)  # informational: random policy may earn 0

    print("\n[parity] 6. flag patterns (is_first / is_last / is_terminal)")
    for name, r in (("online", on), ("demo", de)):
        isf, isl, ist = r["is_first"][:, 0], r["is_last"][:, 0], r["is_terminal"][:, 0]
        check(f"{name}: is_first only on row 0", bool(isf[0]) and not isf[1:].any())
        check(f"{name}: is_last only on the final row", bool(isl[-1]) and not isl[:-1].any())
        check(f"{name}: is_terminal only where is_last (terminal={bool(ist[-1])})",
              not ist[:-1].any())

    print("\n[parity] 7. bookkeeping columns")
    check("online: episode column constant slot id 0", (on["episode"] == 0).all())
    check("demo:   episode column constant stream id 0", (de["episode"] == 0).all())
    check("online: is_demo all False", not on["is_demo"].any())
    check("demo:   is_demo all True", de["is_demo"].all())

    # ---------------------------------------------------------------- side-by-side
    def fmt_rows(r, idxs):
        out = []
        for i in idxs:
            a = np.array2string(r["action"][i].numpy(), precision=2, floatmode="fixed",
                                suppress_small=True, max_line_width=200)
            out.append(f"    t={i:>4}  act={a}  rew={float(r['reward'][i, 0]):+.1f}  "
                       f"first={int(r['is_first'][i, 0])} last={int(r['is_last'][i, 0])} "
                       f"term={int(r['is_terminal'][i, 0])} demo={int(r['is_demo'][i, 0])} "
                       f"ep={int(r['episode'][i])}")
        return "\n".join(out)


    for name, r in (("ONLINE episode (as stored)", on), ("DEMO episode (as stored)", de)):
        n = r["reward"].shape[0]
        print(f"\n{name}: {n} rows -- first 3 / last 3")
        print(fmt_rows(r, [0, 1, 2]))
        print("    ...")
        print(fmt_rows(r, [n - 3, n - 2, n - 1]))

    print()
    if failures:
        print(f"BUFFER PARITY: {len(failures)} FAILURE(S): {failures}")
        sys.exit(1)
    print("BUFFER PARITY: ALL CHECKS PASS -- online and demo rows share one convention")


if __name__ == "__main__":
    main()
